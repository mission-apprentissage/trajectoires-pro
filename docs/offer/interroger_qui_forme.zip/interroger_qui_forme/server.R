function(input, output,session) {
  
  valeur <- reactiveValues(
    "code_certification_ensemble"=NULL,
    "uai_cible"=NULL
    )
  
  observe({
    query <- parseQueryString(session$clientData$url_search)
    uai <- query[["uai"]]
    if (!is.null(uai)) {
      valeur$uai_cible <- uai
      updateTextInput(session, "uai_cible", value = valeur$uai_cible)
    }
    
  })
  
  code_certification_ensemble <- reactive({
    
    ensemble_liste_formations_ci <- tibble(
      code_RNCP = NA, 
      code_ci = NA,
      libelle_ci = NA,
      libelle_type_ci = NA, 
      Code_Scolarité = NA,
      source = NA, 
      cfd = NA,
      Etat_Libelle=NA) %>% 
      slice(0)
    
    
    if(!(input$uai_cible=="")){
      liste_uai <- get_liste_uai_associe_by_lib(query = input$uai_cible)
      
      if(max(liste_uai$nb_uai) >= nrow(liste_uai)){
        liste_siret <- liste_uai %>% 
          filter(numero_siren_siret_uai!="") %>% 
          distinct(numero_siren_siret_uai)
        
        ensemble_liste_formations_ci <- map_dfr(liste_siret$numero_siren_siret_uai,function(siret){
          result <- get_organisme_info(siret, token=token_quiforme )
          
          liste_formations_ci <- tibble(
            code_RNCP = map_chr(result$habilitations,~ifelse(is.null(.$code_fc),NA,.$code_fc))
          ) %>% 
            distinct()  %>% 
            mutate(code_RNCP=str_remove(code_RNCP,"RNCP")) %>% 
            left_join(
              table_correspondance_ci_rncp_code_scolarite,
              by=c("code_RNCP")
            ) %>% 
            drop_na(code_ci) 
          
          return(liste_formations_ci)
          
        })
        
      }
      
    }
    
    return(ensemble_liste_formations_ci)
  })
  
  
  observe({
    valeur$uai_cible <- input$uai_cible
    valeur$code_certification_ensemble <- code_certification_ensemble()
  })
  
  observeEvent(input$validation_recherche_uai,{
    if(nrow(valeur$code_certification_ensemble)==0){
      shinyalert("Oops!", "UAI renseignée incorrecte", type = "error")
    }
    })


  
  code_certification_filtre <- reactive({
    if(!is.null(input$type_diplome_cible)){
      ensemble_liste_formations_ci_filtre <- valeur$code_certification_ensemble
      
      ensemble_liste_formations_ci_filtre <- ensemble_liste_formations_ci_filtre %>%
        filter(libelle_type_ci %in% input$type_diplome_cible)
      
      
      
      ensemble_liste_formations_ci_filtre <- ensemble_liste_formations_ci_filtre %>%
              mutate(data=map(code_ci,~
                                get_sise_certification_intercariforef(code_ci_cible = .,token_ci = token_certifinfos))) %>%
              unnest(data) %>%
              mutate_all(as.character) %>%
              mutate(code_certification=NA)


            if("code_sise" %in% names(ensemble_liste_formations_ci_filtre)){
              ensemble_liste_formations_ci_filtre <- ensemble_liste_formations_ci_filtre %>%
                mutate(code_certification=ifelse(
                  !is.na(code_sise),paste0("SISE:",code_sise),code_certification
                ))
            }

            if("cfd" %in% names(ensemble_liste_formations_ci_filtre)){
              ensemble_liste_formations_ci_filtre <- ensemble_liste_formations_ci_filtre %>%
                mutate(code_certification=ifelse(
                  !is.na(cfd)&is.na(code_certification),paste0("CFD:",cfd),
                  code_certification
                ))

            }


      ensemble_liste_formations_ci_filtre <- ensemble_liste_formations_ci_filtre %>%
              drop_na(code_certification) %>%
              select(libelle_type_ci,code_certification,code_ci,libelle_ci,Etat_Libelle) %>%
              setNames(c("Type de diplome","Code certification","Code CertifInfos","Libelle formation","Etat"))

    }else{
      ensemble_liste_formations_ci_filtre <- NULL
    }
    return(ensemble_liste_formations_ci_filtre)
  })
  
  output$ui_type_diplome_cible <- renderUI({
    if(!is.null(valeur$code_certification_ensemble)){
      if(nrow(valeur$code_certification_ensemble)>0){

        pickerInput(
          inputId = "type_diplome_cible",
          label = "Choix des type(s) de diplôme(s) cible",
          choices = sort(unique(valeur$code_certification_ensemble$libelle_type_ci)),
          selected = sort(unique(valeur$code_certification_ensemble$libelle_type_ci))[1],
          options = pickerOptions(
            actionsBox = TRUE,
            title = "Filtrer les types de formations"
          ),
          multiple = TRUE
        )
      }
    }
  })
  
  
  
  # observe({
  #   updatePickerInput(
  #     session = session,
  #     inputId = "code_certification",
  #     choices = code_certification_filtre()$libelle_ci
  #   )
  # 
  # })
  
  # code_certification_select <- reactive({
  #   if(!is.null(code_certification_filtre())){
  #     if(nrow(code_certification_filtre()>0)){
  #       temp <- code_certification_filtre() %>%
  #         filter(libelle_ci %in% input$code_certification) %>%
  #         mutate(data=map(code_ci,~
  #                           get_sise_certification_intercariforef(code_ci_cible = .,token_ci = token_certifinfos))) %>%
  #         unnest(data) %>%
  #         mutate_all(as.character) %>%
  #         mutate(code_certification=NA)
  #       
  #       
  #       if("code_sise" %in% names(temp)){
  #         temp <- temp %>%
  #           mutate(code_certification=ifelse(
  #             !is.na(code_sise),paste0("SISE:",code_sise),code_certification
  #           ))
  #       }
  #       
  #       if("cfd" %in% names(temp)){
  #         temp <- temp %>%
  #           mutate(code_certification=ifelse(
  #             !is.na(cfd)&is.na(code_certification),paste0("CFD:",cfd),
  #             code_certification
  #           ))
  #         
  #       }
  #       
  # 
  #       temp %>%
  #         drop_na(code_certification) %>%
  #         select(libelle_type_ci,code_certification,code_ci,libelle_ci,Etat_Libelle) %>%
  #         setNames(c("Type de diplome","Code certification","Code CertifInfos","Libelle formation","Etat"))
  #     }
  #   }
  #   })
  
  
  output$code_certification_select_1 <- renderDataTable({
      if(!is.null(code_certification_filtre())){
        if(nrow(code_certification_filtre()>0)){
          DT::datatable(code_certification_filtre(),filter="top",options = list(dom = 't'),rownames = F)
        }
      }
  })
}