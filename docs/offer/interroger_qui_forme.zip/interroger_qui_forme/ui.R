fluidPage(
  tags$head(
    tags$style(".col1 {min-width: 150px; display: inline-block; }"),
    tags$style(".col2 {min-width: auto;  display: inline-block; }"),
    tags$style(".col3 {min-width: auto;  display: inline-block; }"),
    tags$style(".col4 {min-width: auto;  display: inline-block; }"),
    tags$style(".col5 {min-width: auto;  display: inline-block; }")
  ),
  fluidRow(
    tags$h3("Recherche de certifications associées à un UAI"),
    textInput(inputId="uai_cible",label="Choix de l'UAI cible",placeholder = "0762762P"),
    uiOutput("ui_type_diplome_cible"),
    actionButton("validation_recherche_uai",label = "Rechercher les certifications")
  ),

  tags$h3("Resultat de la recherche"),
  
  withSpinner(dataTableOutput("code_certification_select_1")),
 )
