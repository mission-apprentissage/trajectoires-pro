library(shiny)
library(shinyWidgets)
library(tidyverse)
library(dqshiny)
library(httr)
library(jsonlite)
library(DT)
library(shinycssloaders)
library(shinyalert)

token_quiforme <- "Vx29V9AwGyhqlaDGVbk81SZoPhl3GEQwHPrbi3LwSzDMZpVgxTrdBU886XGyG5Av"
token_certifinfos <-"tq6xIPVjlN0fyyiZyWst0gsmiyCFO7W4b3WEj7R9WVvG6W9jta3LjJT23lFsfYkSh"

## ACCE ----

# Import des données ACCE
# https://www.education.gouv.fr/acce/search.php?mode=simple

ACCE_UAI <- data.table::fread("data/ACCE/ACCE_UAI.csv",
                              encoding = "Latin-1") %>%  
  mutate(academie=str_pad(academie,side = "left",pad="0",width=2))


ACCE_UAI_MERE <- read_csv2("data/ACCE/ACCE_UAI_MERE.csv", 
                           locale = locale(encoding = "ISO-8859-1"))


base_acce <- ACCE_UAI_MERE %>% 
  select(numero_uai_mere,numero_uai_trouve) %>% 
  left_join(
    ACCE_UAI %>% 
      select(numero_uai,numero_siren_siret_uai,appellation_officielle,adresse_uai,code_postal_uai,localite_acheminement_uai),
    by=c("numero_uai_trouve"="numero_uai")
  ) %>% 
  bind_rows(
    ACCE_UAI_MERE %>% 
      distinct(numero_uai_mere) %>% 
      left_join(
        ACCE_UAI %>% 
          select(numero_uai,numero_siren_siret_uai,appellation_officielle,adresse_uai,code_postal_uai,localite_acheminement_uai),
        by=c("numero_uai_mere"="numero_uai")
      ) %>% 
      mutate(numero_uai_trouve=numero_uai_mere)
  ) %>% 
  distinct() %>% 
  mutate(
    lib=case_when(
      numero_uai_mere==numero_uai_trouve ~ paste(numero_uai_mere,numero_siren_siret_uai,appellation_officielle,adresse_uai,code_postal_uai,localite_acheminement_uai,sep = ", "),
      numero_uai_mere!=numero_uai_trouve ~ paste(numero_uai_mere,numero_uai_trouve,numero_siren_siret_uai,appellation_officielle,adresse_uai,code_postal_uai,localite_acheminement_uai,sep = ", ")
    ),
    lib= iconv(lib,to="ASCII//TRANSLIT"),
    lib=str_to_upper(lib),
    relation=case_when(
      numero_uai_mere==numero_uai_trouve ~ "uai self",
      numero_uai_mere!=numero_uai_trouve ~ "uai mere-fille"
    ),
    relation=factor(relation,levels=c("uai self","uai mere-fille"))
  ) %>% 
  group_by(numero_uai_mere) %>% 
  mutate(nb_uai=n())


## CertifInfos ----
# Import des données depuis data.gouv.fr
# https://www.data.gouv.fr/fr/datasets/referentiel-national-des-certifications/


opendata_certifinfo <- read_csv("https://tabular-api.data.gouv.fr/api/resources/f2981d6f-e55c-42cd-8eba-3e891777e222/data/csv/")


## Données onisep ----

### Onisep - Table de passage codes certifications et formations----
# Récupération des correspondances entre codes certifications et formations

table_de_passage_codes_certifications_et_formations <- jsonlite::fromJSON("https://api.opendata.onisep.fr/downloads/6152ccdf850ef/6152ccdf850ef.json") %>% 
  as_tibble() %>% 
  mutate_all(~ifelse(.=="",NA,.))

# Import des données ----

## Données BCN ----
# Import des différentes tables depuis le site BCN

# https://bcn.depp.education.fr/bcn/workspace/viewTable/n/N_FORMATION_DIPLOME
n_formation_diplome <- read_csv2("https://bcn.depp.education.fr/bcn/index.php/export/CSV?n=N_FORMATION_DIPLOME&separator=;")


table_correspondance_ci_rncp_code_scolarite <- opendata_certifinfo %>% 
  distinct(Code_Diplome,
           Libelle_Diplome,
           Libelle_Type_Diplome,
           Code_RNCP,Code_Scolarité,
           Etat_Libelle) %>% 
  rename(code_ci=Code_Diplome,
         libelle_ci=Libelle_Diplome,
         libelle_type_ci=Libelle_Type_Diplome,
         code_RNCP=Code_RNCP) %>% 
  mutate_all(as.character)  %>% 
  mutate(source="certifinfos")%>% 
  bind_rows(
    table_de_passage_codes_certifications_et_formations %>% 
      select(certif_info_ci_identifiant,ci_intitule,ci_intitule_type_diplome, ci_code_rncp,ci_code_scolarite) %>% 
      setNames(c("code_ci","libelle_ci","libelle_type_ci","code_RNCP","Code_Scolarité")) %>% 
      mutate_all(as.character) %>% 
      mutate(source="onisep",
             Etat_Libelle="Inconnu")
  ) %>% 
  drop_na(code_RNCP) %>%  
  mutate(source=factor(source,levels=c("certifinfos","onisep"))) %>% 
  group_by(code_ci) %>% 
  filter(as.numeric(source)==min(as.numeric(source))) %>% 
  ungroup() %>% 
  mutate(
    cfd=ifelse(Code_Scolarité%in% n_formation_diplome$FORMATION_DIPLOME,Code_Scolarité,NA)
  ) 

get_liste_uai_associe <- function(uai_demande){
  temp <- ACCE_UAI_MERE %>% 
    filter(numero_uai_trouve==uai_demande) %>% 
    select(numero_uai_mere) %>% 
    rename(uai=numero_uai_mere) %>% 
    mutate(relation="uai mere") %>% 
    bind_rows(
      tibble(
        uai=uai_demande,
        relation="self"
      )
    )
  
  return(temp)
}

get_liste_uai_associe_by_lib <- function(query){
  query <- iconv(str_to_upper(query),to="ASCII//TRANSLIT")
  
  temp <- base_acce %>%
    filter(str_detect(lib,query)) 
  
  return(temp)
}

# get_liste_siret_associe <- function(liste_uai){
#   temp <- ACCE_UAI %>% 
#     as_tibble() %>% 
#     mutate_all(as.character) %>% 
#     select(numero_uai, numero_siren_siret_uai ,appellation_officielle) %>% 
#     inner_join(liste_uai,
#                by=c("numero_uai"="uai")
#     )
#   return(temp)
# }


get_organisme_info <- function(siret, token) {
  url <- paste0("https://api-quiforme-v2.intercariforef.org/organisme/", siret)
  
  response <- GET(
    url,
    add_headers(
      "accept" = "application/json",
      "token-connexion" = token
    )
  )
  
  if (status_code(response) == 200) {
    content(response, as = "parsed", type = "application/json")
  } else {
    stop("Erreur : ", status_code(response), " - ", content(response, as = "text"))
  }
}

get_sise_certification_intercariforef <- function(code_ci_cible,token_ci){
  # Définition de l'URL et des en-têtes
  url <- paste0("https://api-certifinfo.intercariforef.org/certification?id=",code_ci_cible)
  headers <- c(
    "accept" = "application/json",
    "token-connexion" = token_ci
  )
  
  # Effectuer la requête GET
  response <- httr::GET(url, httr::add_headers(.headers = headers))
  json_data <- httr::content(response, as = "parsed", encoding = "UTF-8")
  
  # Extraire les données principales (selon la structure du JSON)
  if(length(json_data$certification)>0){
    results <- json_data$certification[[1]] 
    
    # Construction d'un tibble avec les champs utiles
    temp <-   tibble(
      code_sise=NA,
      ancien_code_ci = NA,
      nouveau_code_ci = NA,
      scolarite_code = NA
    )  %>% 
      mutate(
        code_sise=ifelse(is.null(unlist(results$code_sise)),NA,unlist(results$code_sise)),
        ancien_code_ci=ifelse(is.null(results$ancienne_certification),NA,paste0(map_chr(results$ancienne_certification, ~.$certifinfo_code),collapse = ";")),
        nouveau_code_ci=ifelse(is.null(results$nouvelle_certification),NA,paste0(map_chr(results$nouvelle_certification, ~.$certifinfo_code),collapse = ";")),
        scolarite_code=ifelse(is.null(results$scolarite_code),NA,results$scolarite_code),
      ) %>% 
      mutate_all(~ifelse(.=="",NA,.)) %>% 
      mutate(
        code_sise=ifelse(is.null(unlist(results$code_sise)),NA,code_sise),
        scolarite_code=ifelse(!is.na(code_sise),NA,scolarite_code)
      )
    
  }else{
    temp<-NULL
  }
  
  
  return(temp)
}
