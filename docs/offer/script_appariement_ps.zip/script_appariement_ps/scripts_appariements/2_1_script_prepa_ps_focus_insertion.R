# Script d'appariement des formations Parcoursup aux données d'insertion traitées par la DEPP et le SIES 
# 
# Ce script tente de faire correspondre les données de Parcoursup avec les données de la DEPP et du SIES
# Il explore plusieurs types d'appariements :
#   - normal: Basé sur les codes CFD et MEFSTAT11
#   - MNE: Basé sur la clé des ministères éducatifs
#   - Certif-Infos: Basé sur les codes Certif-Infos
#   - RNCP: Basé sur les codes RNCP
#   - IDEO: Basé sur les codes IDEO
# 
# Pour les formations mixtes (alternance + scolaire), Exposition ne remonte souvent les données que pour une seule des voies.
# Un test inversé est donc réalisé pour essayer de récupérer les informations manquantes.

## Import des données d'Insertion d'Exposition ----

code_region <- c("84", "32", "93", "44", "76", "28", "75", "24", "27", "53", 
                 "52", "11", "94", "01", "02", "03", "04", "06", "00")

forma_test_api_json_route_formation <- map_dfr(code_region,function(x){
  print(x)
  url_reg <- paste0(urls$exposition_ij[[choix_api_exposition]],"/api/inserjeunes/formations?items_par_page=999999&apiKey=",apiKey_ij,"&regions=",x)
  forma_test_api_json_route_formation_reg <- jsonlite::fromJSON(url_reg)
  forma_test_api_json_route_formation_reg <- forma_test_api_json_route_formation_reg$formations %>%
    as_tibble()
  return(forma_test_api_json_route_formation_reg)
})



data_meta_formationsStats_init <- forma_test_api_json_route_formation %>%
  setNames(names(.) %>%
             str_to_lower() %>%
             str_replace_all(" ", "_"))


data_meta_formationsStats_init_annee_terminales <-    data_meta_formationsStats_init %>%
  unnest(certificationsterminales,names_sep = "certificationsterminales") %>%
  select(code_certification,certificationsterminalescertificationsterminalescode_certification,uai,millesime) %>% 
  left_join(data_meta_formationsStats_init,
            by=c("certificationsterminalescertificationsterminalescode_certification"="code_certification","uai","millesime")) %>% 
  select(-certificationsterminalescertificationsterminalescode_certification)


data_meta_formationsStats_init <- data_meta_formationsStats_init %>% 
  anti_join(data_meta_formationsStats_init_annee_terminales,
            by=c("code_certification","uai","millesime")) %>% 
  bind_rows(
    data_meta_formationsStats_init_annee_terminales    
  )


data_meta_formationsStats_init <- data_meta_formationsStats_init %>%
  mutate(
    id_unique = paste0(data_meta_formationsStats_init$donnee_source$code_certification,"_",ifelse(is.na(uai_donnee),uai,uai_donnee),"_",millesime),
    code_certification_source=data_meta_formationsStats_init$donnee_source$code_certification, 
    type_source=data_meta_formationsStats_init$donnee_source$type,
    niveau_diplome=data_meta_formationsStats_init$diplome$code,
    libelle_type_diplome=data_meta_formationsStats_init$diplome$libelle,
    "Couverture Taux En Emploi 6 Mois" = ifelse(is.na(taux_en_emploi_6_mois), F, T),
    "Couverture Taux Autres 6 Mois" = ifelse(is.na(taux_autres_6_mois), F, T),
    "Couverture Taux En poursuite" = ifelse(is.na(taux_en_formation), F, T)
  ) %>% 
  distinct(
    id_unique,
    code_certification ,
    code_formation_diplome,
    uai,
    uai_type,
    uai_donnee_type,
    type_source,
    filiere,
    millesime,
    niveau_diplome,
    libelle_type_diplome,
    nb_annee_term,
    nb_en_emploi_6_mois,
    nb_poursuite_etudes,
    taux_en_emploi_6_mois,
    taux_autres_6_mois,
    taux_en_formation,
    `Couverture Taux En Emploi 6 Mois`,
    `Couverture Taux Autres 6 Mois`,
    `Couverture Taux En poursuite`
  ) %>%
  mutate(presence_ij = T,
         Avant_apres_continuum = case_when(
           nb_annee_term < 20 ~ "Sous le seuil de 20 élèves",
           type_source %in% c("self","nouvelle") ~ "Avant continuum",
           type_source == "ancienne" ~ "Apres continuum"
         ),
         millesime=str_sub(millesime,-4),
         Couverture=case_when(
           nb_annee_term < 20 ~ "Sous le seuil de 20 élèves",
           !(`Couverture Taux En Emploi 6 Mois` & `Couverture Taux Autres 6 Mois` & `Couverture Taux En poursuite`)  ~ "Non couvert",
           (`Couverture Taux En Emploi 6 Mois` & `Couverture Taux Autres 6 Mois` & `Couverture Taux En poursuite`)& Avant_apres_continuum!="Sous le seuil de 20 élèves"  ~ "Couvert",
           millesime == max(millesime) & str_detect(Avant_apres_continuum, "continuum") ~ "Couvert",
           Avant_apres_continuum =="Avant continuum" ~ "Couvert",
           Avant_apres_continuum =="Apres continuum" ~ "Non couvert",
           T~Avant_apres_continuum
         )
  )  %>%
  left_join(n_formation_diplome %>%
              select(FORMATION_DIPLOME,NIVEAU_FORMATION_DIPLOME),
            by=c("code_formation_diplome" ="FORMATION_DIPLOME")
  ) %>%
  left_join(
    n_niveau_formation_diplome %>%
      select(NIVEAU_FORMATION_DIPLOME,NIVEAU_QUALIFICATION_RNCP),
    by="NIVEAU_FORMATION_DIPLOME"
  ) 


ensemble_data_formationsStats <- data_meta_formationsStats_init %>% 
  mutate(code_certification=case_when(
    filiere =="pro" ~paste0("MEFSTAT11:",code_certification),
    filiere =="apprentissage" ~paste0("CFD:",code_certification),
    filiere =="superieur" ~paste0("SISE:",code_certification),
  ))

### Identification des derniers millésimes disponibles dans Exposition par filière ----


millesime_ij <- data_meta_formationsStats_init %>%
  group_by(filiere) %>% 
  distinct(millesime)


### Identification des nouvelles certifications ----

certifications_normalement_disponibles <- n_mef %>% 
  select(MEF_STAT_11,FORMATION_DIPLOME,DUREE_DISPOSITIF) %>% 
  drop_na() %>% 
  left_join(
    n_formation_diplome %>% 
      select(FORMATION_DIPLOME,contains("ANCIEN_DIPLOME_")) %>%
      mutate_all(as.character) %>% 
      pivot_longer(cols=contains("ANCIEN_DIPLOME_"),values_to = "ANCIEN_CFD") %>% 
      select(-name)  %>% 
      bind_rows(
        n_formation_diplome %>% 
          select(FORMATION_DIPLOME) %>% 
          mutate(ANCIEN_CFD=FORMATION_DIPLOME)
      ) %>% 
      drop_na() %>% 
      left_join(
        n_formation_diplome %>% 
          select(FORMATION_DIPLOME,DATE_OUVERTURE),
        by=c("ANCIEN_CFD"="FORMATION_DIPLOME")
      ) %>% 
      drop_na() %>% 
      mutate(                
        DATE_OUVERTURE=as.Date(DATE_OUVERTURE,c("%d/%m/%Y"))
      ) %>% 
      group_by(FORMATION_DIPLOME) %>% 
      filter(DATE_OUVERTURE==min(DATE_OUVERTURE)) %>% 
      ungroup() %>% 
      select(FORMATION_DIPLOME,DATE_OUVERTURE) ,
    by="FORMATION_DIPLOME"
  ) %>% 
  mutate(
    ANNEE_PREMIERE_SORIE_SESSION=year(DATE_OUVERTURE)+DUREE_DISPOSITIF+1) %>% 
  group_by(MEF_STAT_11) %>%
  filter(ANNEE_PREMIERE_SORIE_SESSION==min(ANNEE_PREMIERE_SORIE_SESSION)) %>% 
  ungroup() %>% 
  filter(ANNEE_PREMIERE_SORIE_SESSION<=(millesime_ij %>% 
                                          filter(filiere=="superieur") %>% 
                                          pull(millesime) %>% 
                                          unique() %>% 
                                          as.numeric())) %>% 
  distinct(FORMATION_DIPLOME) %>% 
  pull(FORMATION_DIPLOME)


### Identification des établissements ouverts au moment de la diffusion des millésimes ----

ACCE_UAI <- ACCE_UAI %>% 
  as_tibble() %>% 
  mutate_at(vars(date_ouverture,date_fermeture),
            as.Date,format="%d/%m/%Y") %>% 
  filter(lubridate::year(date_fermeture)>=max(millesime_ij$millesime)|is.na(date_fermeture)) %>% 
  filter(lubridate::year(date_ouverture)<=max(millesime_ij$millesime)|is.na(date_ouverture)) %>% 
  select(numero_uai,academie)

## Appariement avec les données InserJeunes ----


parcoursup_prepa_insertion <- parcoursup_param %>% 
  pivot_longer(cols = intersect(names(.),c("ancien","self","nouveau")),names_to = "anciennete_certification_ci" ,values_to ="code_certification_possible") %>% 
  unnest("code_certification_possible") %>% 
  pivot_longer(cols = intersect(names(.),c("normal","inverse")),names_to = "appariement" ,values_to ="code_certification_possible") %>% 
  filter(!is.na(code_certification_possible)) %>% 
  select(UAI_GES,UAI_AFF,UAI_COMPOSANTE,CODEFORMATIONACCUEIL,code_certification_possible,appariement,type_certification,validite_code_certification,anciennete_certification_ci) %>%   
  pivot_longer(cols = contains("UAI"),names_to = "type_uai",values_to = "uai") %>% 
  select(type_uai,uai,everything())  %>% 
  left_join(
    ACCE_UAI_MERE %>% 
      distinct(numero_uai_trouve,numero_uai_mere),
    by=c("uai"="numero_uai_trouve")
  ) %>% 
  pivot_longer(cols=c(uai,numero_uai_mere),values_to = "uai",names_to = "fille_mere_uai") %>% 
  drop_na(uai) %>% 
  mutate(
    appariement=factor(appariement,levels=c("normal","inverse")),
    anciennete_certification_ci=factor(anciennete_certification_ci,levels=c("self","nouveau","ancien")),
    type_uai=ifelse(fille_mere_uai=="numero_uai_mere",paste0(type_uai,"_MERE") ,type_uai),
    type_uai=factor(type_uai,levels=c("UAI_COMPOSANTE","UAI_AFF","UAI_GES","UAI_COMPOSANTE_MERE","UAI_AFF_MERE","UAI_GES_MERE"))
  ) %>% 
  select(-fille_mere_uai) 





parcoursup_prepa_insertion_couvert <- parcoursup_prepa_insertion %>% 
  inner_join(
    ensemble_data_formationsStats %>%
      select(uai,code_certification,nb_annee_term,taux_en_emploi_6_mois,taux_en_formation,taux_autres_6_mois,Couverture) %>%
      distinct(),
    by=c("uai","code_certification_possible"="code_certification")) %>%  
  group_by(CODEFORMATIONACCUEIL) %>%
  filter(as.numeric(type_uai)==min(as.numeric(type_uai))) %>%  
  ungroup() %>%
  select(-type_uai,-uai) %>% 
  distinct() %>% 
  group_by(CODEFORMATIONACCUEIL) %>%
  filter(as.numeric(appariement)==min(as.numeric(appariement))) %>%   
  ungroup() %>%
  distinct() %>% 
  group_by(CODEFORMATIONACCUEIL) %>%
  filter(as.numeric(type_certification)==min(as.numeric(type_certification))) %>% 
  ungroup() %>%
  distinct() %>% 
  group_by(CODEFORMATIONACCUEIL) %>%
  filter(as.numeric(anciennete_certification_ci)==min(as.numeric(anciennete_certification_ci))) %>% 
  ungroup() %>%
  distinct() %>% 
  group_by(CODEFORMATIONACCUEIL) %>%
  mutate(
    Couverture=case_when(
      n() > 1 ~"Non couvert - Plusieurs codes certification associés",
      Couverture =="Sous le seuil de 20 élèves" ~ "Non couvert - Sous le seuil de 20 élèves",
      Couverture =="Non couvert" ~ "Non couvert - Sans raison évidente",
      validite_code_certification == "Non valide - Plusieurs codes certification associés" ~ "Non couvert - Plusieurs certifications associées au départ dont une seule est couverte",
      T~Couverture
    )
  ) %>% 
  ungroup() %>%
  select(-validite_code_certification,-anciennete_certification_ci)


parcoursup_prepa_insertion_non_couvert <- parcoursup_catalogue_init %>% 
  anti_join(
    parcoursup_prepa_insertion_couvert %>% 
      ungroup() %>%
      distinct(CODEFORMATIONACCUEIL,Couverture),
    by="CODEFORMATIONACCUEIL"
  ) %>% 
  left_join(
    parcoursup_param_code_certification_init %>% 
      mutate(validite_code_certification=factor(validite_code_certification,levels=c("Valide","Non valide - Plusieurs codes certification associés","Non valide - Code inconnu"))) %>% 
      group_by(CODEFORMATIONACCUEIL) %>%
      filter(as.numeric(validite_code_certification)==min(as.numeric(validite_code_certification))) %>% 
      distinct(CODEFORMATIONACCUEIL,validite_code_certification) ,
    by="CODEFORMATIONACCUEIL"
  ) %>% 
  left_join(
    ACCE_UAI %>% 
      distinct(numero_uai,academie),
    by=c("UAI_AFF"="numero_uai")
  ) %>% 
  mutate(
    Couverture=case_when(
      !CODECFD %in% c(certifications_normalement_disponibles,NA) ~ "Non couvert - Nouvelle formation",
      str_sub(academie,1,1)=="4" ~ "Non couvert - Territoire mal couvert",  
      !(UAI_GES %in% ACCE_UAI$numero_uai & UAI_AFF  %in% ACCE_UAI$numero_uai & UAI_COMPOSANTE  %in% ACCE_UAI$numero_uai) ~"Non couvert - UAI Inconnu",
      validite_code_certification=="Valide" ~ "Non couvert - Sans raison évidente",
      validite_code_certification=="Non valide - Plusieurs codes certification associés" ~ "Non couvert - Plusieurs formations en annéee terminale associées",
      validite_code_certification=="Non valide - Code inconnu" ~ "Non couvert - code certification inconnu",
      !(is.na(CODEMEF)& is.na(CODECFD) & is.na(CODESISE) & is.na(LISTE_IDEO) & is.na(ID_RCO) & is.na(LISTE_RNCP)) ~ "Non couvert - code certification inconnu",
      T ~ "Non couvert - code certification absent"
    )
  ) %>% 
  select(-validite_code_certification)


parcoursup_insertion  <- parcoursup_prepa_insertion_couvert %>% 
  mutate_at(vars(nb_annee_term,taux_en_emploi_6_mois,taux_en_formation,taux_autres_6_mois),~ifelse(Couverture!="Couvert",NA,.)) %>% 
  group_by(CODEFORMATIONACCUEIL) %>% 
  mutate(code_certification_possible=ifelse(Couverture=="Non couvert - Plusieurs codes certification associés",paste0(code_certification_possible,collapse = ";",sep=""),code_certification_possible)) %>% 
  ungroup() %>%
  distinct(CODEFORMATIONACCUEIL,Couverture,code_certification_possible,nb_annee_term,taux_en_emploi_6_mois,taux_en_formation,taux_autres_6_mois) %>% 
  bind_rows(
    parcoursup_prepa_insertion_non_couvert %>% 
      distinct(CODEFORMATIONACCUEIL,Couverture)
  ) %>% 
  select(CODEFORMATIONACCUEIL,code_certification_possible,taux_en_emploi_6_mois,taux_en_formation,taux_autres_6_mois,Couverture)%>% 
  rename(
    code_certification_insertion=code_certification_possible,
    Couverture_insertion=Couverture
  )  
