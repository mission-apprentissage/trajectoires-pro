# Script de préparation des données Parcoursup

# Création d'une table de référence contenant les combinaisons uniques de codes CFD, RNCP, IDEO, SISE
# Cette table permettra d'identifier les codes de formation disponibles dans Parcoursup et d'évaluer leur validité

# Fonction pour obtenir la version la plus récente d'un code CFD
get_last_cfd <- function(cfd){
  # Vérifie si le CFD est déjà dans la table v_formation_diplome de la BCN
  if(cfd %in% v_formation_diplome$FORMATION_DIPLOME){
    temp_new <- cfd
    
  # Sinon, regarde dans la table de continuum créée au moment de l'import des données de la BCN  
  }else if(cfd %in% continuum$ancien_cfd){
    temp_new <- cfd
    
    # remonter jusqu'à trouver le dernier CFD connu
    while (length(which(continuum$ancien_cfd == temp_new))>0) {
      temp_new <-continuum$nouveau_cfd[which(continuum$ancien_cfd == temp_new)]
      if(temp_new==cfd) break
    }
    
    # Vérifie si le CFD est dans la table n_formation_diplome de la BCN
  }else if(cfd %in% n_formation_diplome$FORMATION_DIPLOME){
    temp_new <- cfd
  }else{
    temp_new <- NA   # Code inconnu
  }
  
  return(temp_new)
}


# Fonction d'appel API Intercariforef pour récupérer le code SISE associé à un code certif info

get_sise_certification_intercariforef <- function(code_ci_cible,token_ci){
  # Définition de l'URL et des en-têtes
  url <- paste0("https://api-certifinfo.intercariforef.org/certification?id=",code_ci_cible)
  headers <- c(
    "accept" = "application/json",
    "token-connexion" = token_ci
  )
  
  # Effectuer la requête GET
  response <- httr::GET(url, httr::add_headers(.headers = headers))
  json_data <- httr::content(response, as = "parsed", encoding = "UTF-8")
  
  # Extraire les données principales (selon la structure du JSON)
  if(length(json_data$certification)>0){
    results <- json_data$certification[[1]] 
    
    # Construction d'un tibble avec les champs utiles
    temp <-   tibble(
      code_sise=NA,
      ancien_code_ci = NA,
      nouveau_code_ci = NA,
      scolarite_code = NA
    )  %>% 
      mutate(
        code_sise=ifelse(is.null(unlist(results$code_sise)),NA,unlist(results$code_sise)),
        ancien_code_ci=ifelse(is.null(results$ancienne_certification),NA,paste0(map_chr(results$ancienne_certification, ~.$certifinfo_code),collapse = ";")),
        nouveau_code_ci=ifelse(is.null(results$nouvelle_certification),NA,paste0(map_chr(results$nouvelle_certification, ~.$certifinfo_code),collapse = ";")),
        scolarite_code=ifelse(is.null(results$scolarite_code),NA,results$scolarite_code),
      ) %>% 
      mutate_all(~ifelse(.=="",NA,.)) %>% 
      mutate(
        code_sise=ifelse(is.null(unlist(results$code_sise)),NA,code_sise),
        scolarite_code=ifelse(!is.na(code_sise),NA,scolarite_code)
      )
    
  }else{
    temp<-NULL
  }
  
  
  return(temp)
}


# À partir d'ici, traitement du catalogue Parcoursup initial pour transformer les codes en format long
# et gérer les différents types de codes de certification : CODECFD, LISTE_IDEO, LISTE_RNCP, etc.

#Ce bloc vise à transformer la structure du tableau parcoursup_catalogue_init en format long, afin de faciliter
# l’analyse des différents types de codes de certification associés à chaque formation.

parcoursup_catalogue_init_simpli_long <- parcoursup_catalogue_init %>% 
  # On ne garde que les colonnes utiles et on supprime les doublons
  distinct(CODEFORMATIONACCUEIL,APPRENTISSAGEOUSCOLAIRE,CODECFD,CODEMEF,LISTE_RNCP,LISTE_IDEO,CODESISE,ID_RCO)  %>% 
  # Transformation du tableau en format long : chaque ligne contiendra un code de certification et son type
  pivot_longer(cols =-c(CODEFORMATIONACCUEIL,APPRENTISSAGEOUSCOLAIRE),values_to = "code_certification",names_to = "type_certification") %>% 
  # Suppression des lignes avec codes manquants
  drop_na()


#Ce bloc isole les codes de type IDEO depuis la table parcoursup_catalogue_init_simpli_long, les éclate en codes unitaires (car plusieurs sont parfois concaténés), 
#puis tente de les faire correspondre à la table de référence opendata_certifinfo pour retrouver leur code diplôme (code_ci) et potentiellement un CFD.

parcoursup_catalogue_init_simpli_long_ideo <- parcoursup_catalogue_init_simpli_long %>% 
  # Ne garder que les lignes correspondant au type IDEO
  filter(type_certification=="LISTE_IDEO") %>% 
  # On conserve uniquement les codes de certification (IDEO) distincts
  distinct(code_certification) %>% 
  # Séparation des codes multiples (s'ils sont concaténés par des points-virgules) et nettoyage
  mutate(code_certification=map(code_certification,function(x){
    unlist(str_split(x,";")) %>% 
      str_trim()# supprime les espaces superflus
  })) %>% 
  # Dépliage de la liste en lignes individuelles
  unnest() %>% 
  distinct() %>% 
  # On renomme la colonne pour plus de clarté
  setNames("ideo") %>% 
  # Jointure avec les bases de données de référence (opendata_certifinfo + table_de_passage_codes_certifications_et_formations) pour récupérer les infos 
  # associées à l’IDEO
  left_join(
    opendata_certifinfo %>% 
      distinct(Code_Diplome,codeIdeo2,Code_RNCP,Code_Scolarité) %>% 
      rename(code_ci=Code_Diplome,
             code_RNCP=Code_RNCP) %>% 
      mutate_all(as.character) %>% 
      # Fusion avec la table_de_passage_codes_certifications_et_formations issue de l'onisep
      bind_rows(
        table_de_passage_codes_certifications_et_formations %>% 
          select(certif_info_ci_identifiant,ideo_identifiant_formation,ci_code_rncp,ci_code_scolarite) %>% 
          setNames(c("code_ci","codeIdeo2","code_RNCP","Code_Scolarité")) %>% 
          mutate_all(as.character)
      ) %>% 
      distinct() %>% 
      drop_na(codeIdeo2),# On garde uniquement les lignes avec un identifiant IDEO
    by=c("ideo"="codeIdeo2")
  ) %>%
  # Tentative de correspondance avec un CFD (Code_Scolarité): si Code_Scolarité est présent dans n_formation_diplome alors il s'agit bien d'un cfd
  mutate(
    cfd=ifelse(Code_Scolarité%in% n_formation_diplome$FORMATION_DIPLOME,Code_Scolarité,NA)
  )

#Ce bloc prend les codes RNCP issus du catalogue Parcoursup, les éclate si nécessaire, puis essaie de les relier à une certification via 
#les tables de référence (opendata_certifinfo + table_de_passage_codes_certifications_et_formations), pour enfin identifier le code CFD associé.

parcoursup_catalogue_init_simpli_long_rncp <-   parcoursup_catalogue_init_simpli_long %>% 
  # On filtre uniquement les lignes contenant un code RNCP
  filter(type_certification=="LISTE_RNCP") %>%
  # On supprime les doublons
  distinct(code_certification) %>% 
  # Gestion des codes multiples séparés par point-virgule
  mutate(code_certification=map(code_certification,function(x){
    unlist(str_split(x,";")) %>% 
      str_trim()
  })) %>% 
  # Chaque code devient une ligne
  unnest() %>% 
  distinct() %>%
  # On renomme la colonne pour clarté
  setNames("code_RNCP") %>% 
  # Jointure avec les données de référence (certifinfo + table de passage)
  left_join(
    opendata_certifinfo %>% 
      distinct(Code_Diplome,Code_RNCP,Code_Scolarité) %>% 
      rename(code_ci=Code_Diplome,
             code_RNCP=Code_RNCP) %>% 
      mutate_all(as.character) %>% 
      bind_rows(
        table_de_passage_codes_certifications_et_formations %>% 
          select(certif_info_ci_identifiant,ci_code_rncp,ci_code_scolarite) %>% 
          setNames(c("code_ci","code_RNCP","Code_Scolarité")) %>% 
          mutate_all(as.character)
      ) %>% 
      distinct() %>% 
      drop_na(code_RNCP),# Garde uniquement les lignes avec un code RNCP valide
    by=c("code_RNCP")
  ) %>% 
  # Tentative de correspondance avec un CFD (Code_Scolarité): si Code_Scolarité est présent dans n_formation_diplome alors il s'agit bien d'un cfd
  mutate(
    cfd=ifelse(Code_Scolarité%in% n_formation_diplome$FORMATION_DIPLOME,Code_Scolarité,NA)
  )

#Ce bloc nettoie les codes ID_RCO en extrayant la partie numérique correspondant au code CI (Certif Info), puis tente de les faire correspondre à une certification de la base certifinfo. 
#Il essaie également de déterminer un CFD associé.

parcoursup_catalogue_init_simpli_long_id_rco <- parcoursup_catalogue_init_simpli_long %>%
  # On garde uniquement les lignes avec type ID_RCO
  filter(type_certification=="ID_RCO") %>%
  # Le code ID_RCO contient la lettre P : on extrait la partie numérique avant cette lettre qui correspond au code certifinfo.
  mutate(
    code_certification=str_split_fixed(code_certification,"P",2)[,1], # coupe avant le P
    code_certification=as.numeric(code_certification),# transforme en numérique pour retirer les zéros initiaux
    code_certification=as.character(code_certification)# reconverti en texte
  ) %>%
  # On ne garde que les valeurs uniques
  distinct(code_certification) %>% 
  # Renommage : on appelle ce champ 'code_ci'
  setNames("code_ci") %>% 
  # Jointure avec les tables de référence (opendata_certifinfo + table_de_passage_codes_certifications_et_formations)
  left_join(
    opendata_certifinfo %>%
      distinct(Code_Diplome,Code_RNCP,Code_Scolarité) %>%
      rename(code_ci=Code_Diplome,
             code_RNCP=Code_RNCP) %>%
      mutate_all(as.character) %>%
      bind_rows(
        table_de_passage_codes_certifications_et_formations %>%
          select(certif_info_ci_identifiant,ci_code_rncp,ci_code_scolarite) %>%
          setNames(c("code_ci","code_RNCP","Code_Scolarité")) %>%
          mutate_all(as.character)
      ) %>%
      distinct() %>%
      drop_na(code_RNCP), # on ne garde que les codes valides
    by=c("code_ci")
  ) %>%
  # Tentative de correspondance avec un CFD (Code_Scolarité): si Code_Scolarité est présent dans n_formation_diplome alors il s'agit bien d'un cfd
  mutate(
    cfd=ifelse(Code_Scolarité%in% n_formation_diplome$FORMATION_DIPLOME,Code_Scolarité,NA)
  )


#Ce bloc crée une table avec tous les couples code_ci ↔ CFD identifiés, 
#puis utilise l'API Intercariforef pour enrichir chaque ligne avec les codes SISE, 
#ainsi que les certifications anciennes et nouvelles associées. 
#Il relance les appels API pour récupérer les codes SISE des certifications anciennes et nouvelles identifiées.

#C'est un bloc crucial pour établir une cartographie complète des codes de certification de parcoursup.

parcoursup_catalogue_init_simpli_long_code_ci_ok_correspondance <- tibble(
  # Regroupe les code_ci et cfd issus des 3 blocs précédents (IDEO, RNCP, ID_RCO)
  code_ci = c(parcoursup_catalogue_init_simpli_long_rncp$code_ci,
              parcoursup_catalogue_init_simpli_long_ideo$code_ci,
              parcoursup_catalogue_init_simpli_long_id_rco$code_ci),
  cfd = c(parcoursup_catalogue_init_simpli_long_rncp$cfd,
          parcoursup_catalogue_init_simpli_long_ideo$cfd,
          parcoursup_catalogue_init_simpli_long_id_rco$cfd
  )
) %>% 
  distinct() %>% # Supprime les doublons éventuels
  drop_na(code_ci)  %>% # On garde seulement les lignes avec un code_ci valide
  mutate(
    #Ici, on interroge l’API Intercariforef pour chaque code_ci et on stocke la réponse (code SISE, codes CI liés, code scolarité).
    api_certification_rco=map2(code_ci,cfd,function(x,y){
      if(!is.na(x)){
        get_sise_certification_intercariforef(code_ci_cible = x,token_ci=token_ci)
      }else{
        tibble(
          code_sise=NA,
          ancien_code_ci = NA ,
          nouveau_code_ci= NA,
          scolarite_code=NA
        )
      }
    })
  ) %>%   
  unnest(api_certification_rco) %>% 
  mutate_all(~ifelse(.=="",NA,.)) %>%
  #Sépare les anciens codes CI s'ils sont concaténés, puis les transforme en lignes individuelles.
  mutate(ancien_code_ci=map(ancien_code_ci,function(x){
    unlist(str_split(x,";")) %>% 
      str_trim()
  })) %>% 
  unnest() %>% 
  distinct() %>% 
  mutate(
    #Deuxième appel API : pour récupérer le code SISE des anciens codes CI
    api_certification_rco=map2(ancien_code_ci,cfd,function(x,y){
      if(!is.na(x)){
        temp <- get_sise_certification_intercariforef(code_ci_cible = x,token_ci=token_ci) 
        if("code_sise" %in% names(temp)){
          temp %>% 
            select(code_sise) %>% 
            setNames("ancien_code_sise")
        }else{
          tibble(
            ancien_code_sise=NA
          )
        }
      }else{
        tibble(
          ancien_code_sise=NA
        )
      }
    })
  ) %>% 
  unnest(api_certification_rco) %>% 
  mutate(
    #Troisième appel API : pour récupérer le code SISE des nouveaux codes CI
    api_certification_rco=map2(nouveau_code_ci,cfd,function(x,y){
      if(!is.na(x)){
        temp <- get_sise_certification_intercariforef(code_ci_cible = x,token_ci=token_ci) 
        if("code_sise" %in% names(temp)){
          temp %>% 
            select(code_sise) %>% 
            setNames("nouveau_code_sise")
        }else{
          tibble(
            nouveau_code_sise=NA
          )
        }
      }else{
        tibble(
          nouveau_code_sise=NA
        )
      }
    })
  ) %>% 
  unnest(api_certification_rco) %>% 
  #réajustement CFD si le code SISE est présent
  mutate(cfd=case_when(
    !is.na(code_sise)~NA,
    !is.na(cfd)~cfd,
    scolarite_code %in% n_formation_diplome$FORMATION_DIPLOME~scolarite_code
  ))


#Ce bloc permet de mettre à jour les CFD manquants pour les codes IDEO, en les enrichissant avec la correspondance obtenue via les appels API précédents. 
#Si un CFD est déjà présent, on le garde ; sinon, on remplace par celui obtenu via code_ci.


parcoursup_catalogue_init_simpli_long_ideo_ok_correspondance <- parcoursup_catalogue_init_simpli_long_ideo %>% 
  # On force tous les champs en texte pour éviter les problèmes de typage lors des jointures
  mutate_all(as.character) %>% 
  # Jointure avec la table contenant les correspondances enrichies (code_ci ↔ CFD)
  left_join(
    parcoursup_catalogue_init_simpli_long_code_ci_ok_correspondance %>% 
      rename(cfd_apres_correspondance=cfd) %>% 
      distinct(),# on retire les doublons potentiels
    by=c("code_ci")
  ) %>% 
  distinct()  %>% # on retire les doublons potentiels
  mutate(
    # Mise à jour du champ CFD : si vide, on utilise celui obtenu par correspondance
    cfd=ifelse(is.na(cfd),cfd_apres_correspondance,cfd)
  ) %>% 
  # Suppression de la colonne temporaire utilisée pour la mise à jour
  select(-cfd_apres_correspondance)


parcoursup_catalogue_init_simpli_long_rncp_ok_correspondance <- parcoursup_catalogue_init_simpli_long_rncp %>% 
  # On force tous les champs en texte pour éviter les problèmes de typage lors des jointures
  mutate_all(as.character) %>%
  # Jointure avec la table contenant les correspondances enrichies (code_ci ↔ CFD)
  left_join(
    parcoursup_catalogue_init_simpli_long_code_ci_ok_correspondance %>% 
      rename(cfd_apres_correspondance=cfd) %>% 
      distinct(),# on retire les doublons potentiels
    by=c("code_ci")
  ) %>% 
  distinct() %>% # on retire les doublons potentiels
  mutate(
    # Mise à jour du champ CFD : si vide, on utilise celui obtenu par correspondance
    cfd=ifelse(is.na(cfd),cfd_apres_correspondance,cfd)
  ) %>% 
  # Suppression de la colonne temporaire utilisée pour la mise à jour
  select(-cfd_apres_correspondance)

parcoursup_catalogue_init_simpli_long_id_rco_ok_correspondance <- parcoursup_catalogue_init_simpli_long_id_rco %>% 
  # On force tous les champs en texte pour éviter les problèmes de typage lors des jointures
  mutate_all(as.character) %>% 
  # Jointure avec la table contenant les correspondances enrichies (code_ci ↔ CFD)
  left_join(
    parcoursup_catalogue_init_simpli_long_code_ci_ok_correspondance %>% 
      rename(cfd_apres_correspondance=cfd) %>% 
      distinct(),# on retire les doublons potentiels
    by=c("code_ci")
  ) %>% 
  distinct() %>% # on retire les doublons potentiels
  mutate(
    # Mise à jour du champ CFD : si vide, on utilise celui obtenu par correspondance
    cfd=ifelse(is.na(cfd),cfd_apres_correspondance,cfd)
  ) %>% 
  # Suppression de la colonne temporaire utilisée pour la mise à jour
  select(-cfd_apres_correspondance)


## CODECFD ----

# Ce bloc :
#   1- Extrait les codes CFD déclarés dans Parcoursup.
#   2- Vérifie s’ils sont valides en les comparant à la nomenclature nationale (n_formation_diplome).
#   3- Produit une version formatée (CFD:xxxx) pour un usage harmonisé.
#   4- Y associe un code CI (Certif Info) en croisant avec la base opendata_certifinfo

print("Prepa data - Ensemble codes certifications possibles - CFD")
parcoursup_nomenclature_de_ref_correspondance_code_certification_ensemble_codes_possibles_cfd <- parcoursup_catalogue_init_simpli_long %>% 
  # Sélectionne uniquement les lignes où le type de certification est 'CODECFD'
  filter(type_certification=="CODECFD") %>% 
  # Garde les colonnes essentielles et retire les doublons
  distinct(type_certification,code_certification,CODEFORMATIONACCUEIL) %>% 
  # Marque chaque code comme valide ou non en fonction de sa présence dans la base nationale
  mutate(
    validite_code_certification=ifelse(code_certification %in% n_formation_diplome$FORMATION_DIPLOME,"Valide","Non valide - Code inconnu")
  )  %>% 
  # Crée une version normalisée du code pour les appariements 
  mutate(
    code_certification_possible = paste0("CFD:",code_certification )
  ) %>% 
  # Nettoie les doublons après transformation
  distinct(type_certification,
           code_certification,
           code_certification_possible,
           validite_code_certification) %>% 
  left_join(
    opendata_certifinfo %>% 
      group_by(Code_Scolarité) %>%
      mutate(
        filtre_unique_ci=case_when(
          n()==1~T,
          Annee_Premiere_Session==max(Annee_Premiere_Session)~T,
          is.na(Annee_Derniere_Session)~T,
          Annee_Derniere_Session==max(Annee_Derniere_Session)~T,
          T~F
        )
      ) %>% 
      filter(filtre_unique_ci) %>% 
      slice(1) %>%# on garde 1 seul code CI par code Scolarité si après les filtres il en reste encore plusieurs
      ungroup() %>% 
      distinct(Code_Diplome,Code_Scolarité)  %>% 
      drop_na() %>% 
      rename(code_ci=Code_Diplome) %>% 
      mutate(code_ci=as.character(code_ci)),
    by=c("code_certification"="Code_Scolarité")
  ) 



## CODEMEF ----
# Ce bloc vérifie la validité des codes MEF utilisés dans Parcoursup, 
# les transforme en code MEFSTAT11 (version à 11 caractères) et tente de retrouver un code CI correspondant via plusieurs jointures croisées.

print("Prepa data - Ensemble codes certifications possibles - MEF")
parcoursup_nomenclature_de_ref_correspondance_code_certification_ensemble_codes_possibles_mef <- parcoursup_catalogue_init_simpli_long %>% 
  # Filtrage sur les certifications de type MEF
  filter(type_certification=="CODEMEF") %>% 
  # Sélection des colonnes pertinentes et suppression des doublons
  distinct(type_certification,code_certification,CODEFORMATIONACCUEIL) %>% 
  # Validation des codes MEF via la table de référence n_mef
  mutate(
    validite_code_certification=ifelse(code_certification %in% n_mef$MEF,"Valide","Non valide - Code inconnu")
  ) %>% 
  left_join(
    n_mef %>% 
      select(MEF,MEF_STAT_11),
    by=c("code_certification"="MEF")
  ) %>% 
  # Formatage du code MEFSTAT11 pour harmonisation
  mutate(
    code_certification_possible = paste0("MEFSTAT11:",MEF_STAT_11 )
  ) %>% 
  distinct(type_certification,
           code_certification,
           code_certification_possible,
           validite_code_certification) %>% 
  left_join(
    #Associe chaque MEF à son code formation diplôme (CFD).
    n_mef %>% 
      select(FORMATION_DIPLOME,MEF),
    by=c("code_certification"="MEF")
  ) %>% 
  left_join(
    #Jointure pour trouver le code CI depuis le code scolaire
    opendata_certifinfo %>% 
      group_by(Code_Scolarité) %>%
      mutate(
        filtre_unique_ci=case_when(
          n()==1~T,
          Annee_Premiere_Session==max(Annee_Premiere_Session)~T,
          is.na(Annee_Derniere_Session)~T,
          Annee_Derniere_Session==max(Annee_Derniere_Session)~T,
          T~F
        )
      ) %>% 
      filter(filtre_unique_ci) %>% 
      slice(1) %>%
      ungroup() %>% 
      distinct(Code_Diplome,Code_Scolarité)  %>% 
      drop_na() %>% 
      rename(code_ci=Code_Diplome) %>% 
      mutate(code_ci=as.character(code_ci)),
    by=c("FORMATION_DIPLOME"="Code_Scolarité")
  ) %>% 
  # Nettoyage final
  select(-FORMATION_DIPLOME)



## CODESISE ----
print("Prepa data - Ensemble codes certifications possibles - SISE")
parcoursup_nomenclature_de_ref_correspondance_code_certification_ensemble_codes_possibles_sise <- parcoursup_catalogue_init_simpli_long %>% 
  select(-CODEFORMATIONACCUEIL) %>% 
  # On filtre uniquement les lignes avec type 'CODESISE'
  filter(type_certification=="CODESISE") %>% 
  # On garde les colonnes nécessaires sans doublons
  distinct(type_certification,code_certification) %>% 
  # On vérifie que le code SISE figure dans la table n_diplome_sise de la BCN
  mutate(
    validite_code_certification=ifelse(code_certification %in% n_diplome_sise$DIPLOME_SISE,"Valide","Non valide - Code inconnu")
  ) %>% 
  mutate(
    # On formate le code pour la suite (ex : SISE:XXXXXX)
    code_certification_possible = paste0("SISE:",code_certification )
  ) %>% 
  # Nettoyage final : sélection des champs utiles sans doublons
  distinct(type_certification,code_certification,code_certification_possible,validite_code_certification)



## LISTE_RNCP ----
print("Prepa data - Ensemble codes certifications possibles - RNCP")
parcoursup_nomenclature_de_ref_correspondance_code_certification_ensemble_codes_possibles_rncp <- parcoursup_catalogue_init_simpli_long %>% 
  select(-CODEFORMATIONACCUEIL) %>% 
  filter(type_certification=="LISTE_RNCP") %>% 
  mutate(code_certification_init=code_certification) %>% 
  #découpe les codes multiples s’ils sont concaténés dans une même cellule.
  mutate(code_certification=map(code_certification,function(x){
    unlist(str_split(x,";")) %>% 
      str_trim()
  })) %>% 
  unnest() %>% 
  distinct(type_certification,code_certification_init,code_certification) %>% 
  left_join(
    #Jointure avec les correspondances enrichies (informations sur CFD, SISE, etc.).
    parcoursup_catalogue_init_simpli_long_rncp_ok_correspondance %>% 
      distinct(code_ci,code_RNCP,cfd,code_sise,ancien_code_sise,nouveau_code_sise) %>% 
      pivot_longer(cols=contains("sise"),values_to = "SISE") %>%   
      rename(CFD=cfd) %>% 
      mutate(
        # Classe chaque correspondance selon son ancienneté :
        #   - "self" = code principal
        #   - "ancien" = code lié à une certification antérieure
        #   - "nouveau" = certification qui remplace la précédente
        #   
        #   Objectif: Permettre de pouvoir forcer l'appariement sur self par exemple
        anciennete_certification_ci=case_when(
          !is.na(CFD)~"self",
          name=="ancien_code_sise"~"ancien",
          name=="nouveau_code_sise"~"nouveau",
          T~"self")
      ) %>% 
      select(-name)  %>% 
      pivot_longer(cols = c(CFD,SISE),values_to = "code_certification_ci",names_to = "type_certification_ci") %>% 
      drop_na(code_certification_ci) %>% 
      distinct(),
    by=c("code_certification"="code_RNCP")
  )  %>% 
  select(-code_certification) %>% 
  rename(code_certification=code_certification_init) %>% 
  mutate(
    code_certification_ci=map2(code_certification_ci,type_certification_ci,function(x,y){
      case_when(
        y=="CFD"~get_last_cfd(x), # si c’est un CFD, on prend la version la plus récente
        T~x
      )
    })
  )  %>% 
  unnest(code_certification_ci) %>% 
  mutate(type_certification_ci=ifelse(is.na(code_certification_ci),NA,type_certification_ci)) %>% 
  distinct() %>% 
  group_by(code_certification,anciennete_certification_ci) %>% 
  mutate(
    #Critères de validité : un seul code associé, et existant.
    validite_code_certification=case_when(
      is.na(code_certification_ci)~"Non valide - Code inconnu",
      n()>1~"Non valide - Plusieurs codes certification associés",
      T~"Valide")
  ) %>% 
  ungroup()%>% 
  mutate(
    # Création d’un code standardisé pour exploitation future uniquement si la correspondance est valide.
    code_certification_possible = case_when(
      is.na(code_certification_ci)~NA,
      validite_code_certification!="Valide"~NA,
      T~paste0(type_certification_ci,":",code_certification_ci )
    ),
    code_ci = case_when(
      is.na(code_ci)~NA,
      validite_code_certification!="Valide"~NA,
      T~code_ci
    )
  ) %>% 
  distinct(type_certification,code_certification,code_ci,code_certification_possible,validite_code_certification,anciennete_certification_ci)  



## LISTE_IDEO ----
print("Prepa data - Ensemble codes certifications possibles - IDEO")
parcoursup_nomenclature_de_ref_correspondance_code_certification_ensemble_codes_possibles_ideo <- parcoursup_catalogue_init_simpli_long %>% 
  select(-CODEFORMATIONACCUEIL) %>% 
  filter(type_certification=="LISTE_IDEO") %>% 
  mutate(code_certification_init=code_certification) %>% 
  #découpe les codes multiples s’ils sont concaténés dans une même cellule.
  mutate(code_certification=map(code_certification,function(x){
    unlist(str_split(x,";")) %>% 
      str_trim()
  })) %>% 
  unnest() %>% 
  distinct(type_certification,code_certification_init,code_certification) %>% 
  left_join(
    parcoursup_catalogue_init_simpli_long_ideo_ok_correspondance %>% 
      distinct(code_ci,ideo,cfd,code_sise,ancien_code_sise,nouveau_code_sise) %>% 
      #On transforme les colonnes "CFD", "ancien_code_sise", "nouveau_code_sise" en format long pour pouvoir travailler de manière homogène.
      pivot_longer(cols=contains("sise"),values_to = "SISE") %>%   
      rename(CFD=cfd) %>% 
      mutate(
        anciennete_certification_ci=case_when(
          !is.na(CFD)~"self",
          name=="ancien_code_sise"~"ancien",
          name=="nouveau_code_sise"~"nouveau",
          T~"self")
      ) %>% 
      select(-name)  %>% 
      #On transforme les colonnes "CFD", "ancien_code_sise", "nouveau_code_sise" en format long pour pouvoir travailler de manière homogène.
      pivot_longer(cols = c(CFD,SISE),values_to = "code_certification_ci",names_to = "type_certification_ci") %>% 
      drop_na(code_certification_ci) %>% 
      distinct(),
    by=c("code_certification"="ideo")
  ) %>% 
  select(-code_certification) %>% 
  rename(code_certification=code_certification_init) %>% 
  mutate(
    code_certification_ci=map2(code_certification_ci,type_certification_ci,function(x,y){
      case_when(
        y=="CFD"~get_last_cfd(x), # si c’est un CFD, on prend la version la plus récente
        T~x
      )
    })
  )  %>% 
  unnest(code_certification_ci) %>% 
  mutate(type_certification_ci=ifelse(is.na(code_certification_ci),NA,type_certification_ci)) %>% 
  distinct() %>% 
  group_by(code_certification,anciennete_certification_ci) %>% 
  mutate(
    #Critères de validité : un seul code associé, et existant.
    validite_code_certification=case_when(
      is.na(code_certification_ci)~"Non valide - Code inconnu",
      n()>1~"Non valide - Plusieurs codes certification associés",
      T~"Valide")
  ) %>% 
  ungroup()%>% 
  mutate(
    #Création d’un code standardisé pour exploitation future uniquement si la correspondance est valide.
    code_certification_possible = case_when(
      is.na(code_certification_ci)~NA,
      validite_code_certification!="Valide"~NA,
      T~paste0(type_certification_ci,":",code_certification_ci )
    ),
    code_ci = case_when(
      is.na(code_ci)~NA,
      validite_code_certification!="Valide"~NA,
      T~code_ci
    )
  ) %>% 
  distinct(type_certification,code_certification,code_ci,code_certification_possible,validite_code_certification,anciennete_certification_ci)  



## ID_RCO ----
print("Prepa data - Ensemble codes certifications possibles - ID_RCO")
parcoursup_nomenclature_de_ref_correspondance_code_certification_ensemble_codes_possibles_id_rco <- parcoursup_catalogue_init_simpli_long %>% 
  select(-CODEFORMATIONACCUEIL) %>% 
  filter(type_certification=="ID_RCO") %>% 
  distinct(type_certification,code_certification) %>% 
  mutate(
    #On extrait la partie avant "P", qui correspond au code CI réel.
    code_ci=str_split_fixed(code_certification,"P",2)[,1], # le code certif info compose la clé des ministere educatif (ID_RCO dans parcoursup). La lettre P sépare systématiquement le code certif info du reste du code. Ici on récupère le code certif info.
    code_ci=as.numeric(code_ci),#pour supprimer le 0 s'il y en a un
    code_ci=as.character(code_ci)
  ) %>% 
  left_join(
    parcoursup_catalogue_init_simpli_long_id_rco_ok_correspondance %>% 
      distinct(code_ci,cfd,code_sise,ancien_code_sise) %>% 
      #On transforme les colonnes "CFD", "ancien_code_sise", "nouveau_code_sise" en format long pour pouvoir travailler de manière homogène.
      pivot_longer(cols=contains("sise"),values_to = "SISE") %>%   
      rename(CFD=cfd) %>% 
      mutate(
        anciennete_certification_ci=case_when(
          !is.na(CFD)~"self",
          name=="ancien_code_sise"~"ancien",
          name=="nouveau_code_sise"~"nouveau",
          T~"self")
      ) %>% 
      select(-name)  %>% 
      pivot_longer(cols = c(CFD,SISE),values_to = "code_certification_ci",names_to = "type_certification_ci") %>% 
      drop_na(code_certification_ci) %>% 
      distinct(),
    by=c("code_ci")
  )  %>% 
  mutate(
    code_certification_ci=map2(code_certification_ci,type_certification_ci,function(x,y){
      case_when(
        y=="CFD"~get_last_cfd(x),# si c’est un CFD, on prend la version la plus récente
        T~x
      )
    })
  )  %>% 
  unnest(code_certification_ci) %>% 
  mutate(type_certification_ci=ifelse(is.na(code_certification_ci),NA,type_certification_ci)) %>% 
  distinct() %>% 
  group_by(code_certification,anciennete_certification_ci) %>% 
  mutate(
    #Critères de validité : un seul code associé, et existant.
    validite_code_certification=case_when(
      is.na(code_certification_ci)~"Non valide - Code inconnu",
      n()>1~"Non valide - Plusieurs codes certification associés",
      T~"Valide")
  ) %>% 
  ungroup()%>% 
  mutate(
    # Création d’un code standardisé pour exploitation future uniquement si la correspondance est valide.
    code_certification_possible = case_when(
      is.na(code_certification_ci)~NA,
      validite_code_certification!="Valide"~NA,
      T~paste0(type_certification_ci,":",code_certification_ci )
    ),
    code_ci = case_when(
      is.na(code_ci)~NA,
      validite_code_certification!="Valide"~NA,
      T~code_ci
    )
  ) %>% 
  distinct(type_certification,code_certification,code_ci,code_certification_possible,validite_code_certification,anciennete_certification_ci)  


#Ce bloc :
#     1- Regroupe les résultats validés et formatés de tous les types de certifications,
#     2- Normalise les valeurs manquantes dans le champ anciennete_certification_ci (par défaut : "self").

parcoursup_nomenclature_de_ref_correspondance_code_certification_ensemble_codes_possibles <- bind_rows(
  parcoursup_nomenclature_de_ref_correspondance_code_certification_ensemble_codes_possibles_cfd,
  parcoursup_nomenclature_de_ref_correspondance_code_certification_ensemble_codes_possibles_mef,
  parcoursup_nomenclature_de_ref_correspondance_code_certification_ensemble_codes_possibles_sise,
  parcoursup_nomenclature_de_ref_correspondance_code_certification_ensemble_codes_possibles_rncp,
  parcoursup_nomenclature_de_ref_correspondance_code_certification_ensemble_codes_possibles_ideo,
  parcoursup_nomenclature_de_ref_correspondance_code_certification_ensemble_codes_possibles_id_rco
) %>% 
  mutate(
    anciennete_certification_ci=ifelse(is.na(anciennete_certification_ci),"self",anciennete_certification_ci)
  )

# Objectif de ce bloc : préparer la conversion automatique CFD ↔ MEF dans les cas où on doit inverser les correspondances (par exemple : 
# un code CFD déclaré dans un contexte apprentissage sera converti en MEFSTAT11, et inversement).
# 
# Ce bloc permet d'ajouter le code CFD lorsqu'il s'agit d'une formation en voie scolaire (mestat11). Il ajoute le mefstats11 lorsqu'il s'agit d'une formation en voie 
# apprentissage (cfd). C'est utile car pour certaines formations mixtes, les SSM n'associent les données remontées qu'à l'une des voies (scolaire ou apprentissage). 
# Un établissement ayant une formation mixte ne remontera ses données que pour le mefstat11 par exemple (alors qu'après consultation des SSM, les données correspondent à l'ensemble des élèves).
# Le parti pris est d'exposer les données de cet établissement pour l'apprentissage comme pour le scolaire. 
# Au moment de l'appariement, il sera toujours possible de forcer le script à n'apparier que sur les jointures dites normales.

parcoursup_nomenclature_de_ref_correspondance_code_certification_valide_correspondance_inverse <- parcoursup_nomenclature_de_ref_correspondance_code_certification_ensemble_codes_possibles %>%
  filter(type_certification %in% c("LISTE_RNCP","LISTE_IDEO","ID_RCO")& str_detect(code_certification_possible,"CFD:")) %>%
  distinct(code_certification_possible) %>%
  mutate(code_certification_possible_v2=str_remove(code_certification_possible,"CFD:")) %>%
  left_join(
    n_mef %>%
      mutate(
        DATE_FERMETURE=as.Date(DATE_FERMETURE,"%d/%m/%Y"),
        DATE_OUVERTURE=as.Date(DATE_OUVERTURE,"%d/%m/%Y")
      ) %>%
      filter(
        (is.na(DATE_FERMETURE) | DATE_FERMETURE>=(as.Date("2024/08/31") %m+% years(DUREE_DISPOSITIF))),
        DATE_OUVERTURE <=as.Date("2024/08/31")
      ) %>%
      group_by(FORMATION_DIPLOME) %>%
      filter(ANNEE_DISPOSITIF ==max(ANNEE_DISPOSITIF )) %>%
      select(FORMATION_DIPLOME,MEF_STAT_11) %>%
      distinct(),
    by=c("code_certification_possible_v2"="FORMATION_DIPLOME")
  ) %>%
  drop_na() %>%
  mutate(
    code_certification_possible_inverse = paste0("MEFSTAT11:",MEF_STAT_11 )
  ) %>%
  distinct(code_certification_possible,code_certification_possible_inverse)


# Ce bloc :
#   
#   1- Définit un ordre de priorité sur le champ anciennete_certification_ci,
#   2- Pour chaque combinaison de colonnes (hors ancienneté), ne conserve que la ligne avec l’ancienneté la plus élevée (self > nouveau > ancien),
#   3- Résout donc les cas ambigus où plusieurs correspondances existent pour un même code.

parcoursup_nomenclature_de_ref_correspondance_code_certification_ensemble_codes_possibles <- parcoursup_nomenclature_de_ref_correspondance_code_certification_ensemble_codes_possibles %>% 
  #transforme l’attribut d’ancienneté en facteur ordonné, ce qui permet de le comparer facilement (dans l’ordre souhaité).
  mutate(anciennete_certification_ci=factor(anciennete_certification_ci,levels=c("self","nouveau","ancien"))) %>% 
  #regroupe toutes les lignes identiques à l’exception de l’ancienneté (qui peut différer).
  group_by(across(-anciennete_certification_ci)) %>% 
  # Pour chaque groupe, on conserve uniquement la ligne avec l’ancienneté la plus forte selon notre hiérarchie :
  #     - self = 1 (prioritaire)
  #     - nouveau = 2
  #     - ancien = 3
  filter(as.numeric(anciennete_certification_ci)==min(as.numeric(anciennete_certification_ci))) %>% 
  ungroup()


# Ce bloc :
#     1- Identifie les lignes à inverser (ex : CFD déclaré dans Parcoursup pour une formation en apprentissage),
#     2- Les remplace par leur correspondance inverse (ex : MEFSTAT11 équivalent),
#     3- Fusionne à nouveau les correspondances inverses avec les normales pour constituer une seule table complète.

parcoursup_nomenclature_de_ref_correspondance_code_certification_ensemble_codes_possibles <- parcoursup_nomenclature_de_ref_correspondance_code_certification_ensemble_codes_possibles %>%
  mutate(
    filtre_inverse=case_when(
      type_certification %in% c("LISTE_RNCP","LISTE_IDEO","ID_RCO") & str_detect(code_certification_possible,"CFD:") ~T,
      T~F
    )
  ) %>% 
  filter(!filtre_inverse) %>% 
  bind_rows(
    parcoursup_nomenclature_de_ref_correspondance_code_certification_ensemble_codes_possibles %>%
      mutate(
        filtre_inverse=case_when(
          type_certification %in% c("LISTE_RNCP","LISTE_IDEO","ID_RCO") & str_detect(code_certification_possible,"CFD:") ~T,
          T~F
        )
      ) %>% 
      filter(filtre_inverse) %>% 
      left_join(
        parcoursup_nomenclature_de_ref_correspondance_code_certification_valide_correspondance_inverse,
        by="code_certification_possible"
      )
  ) %>% 
  select(-filtre_inverse)
  

# Ce bloc :
#     1- Met la table au format long, avec deux lignes par code (si inverse existe),
#     2- Étiquette chaque ligne comme "normal" ou "inverse",
#     3- Filtre les inverses vides pour ne garder que les correspondances valides.


parcoursup_nomenclature_de_ref_correspondance_code_certification_ensemble_codes_possibles_long <- parcoursup_nomenclature_de_ref_correspondance_code_certification_ensemble_codes_possibles %>% 
  pivot_longer(cols = contains("code_certification_possible"),names_to = "appariement",values_to = "code_certification_possible") %>% 
  mutate(
    appariement=ifelse(appariement=="code_certification_possible","normal","inverse"),
    appariement=factor(appariement,levels=c("normal","inverse")),
    type_certification=factor(type_certification,levels=c("CODECFD","CODEMEF","CODESISE","ID_RCO","LISTE_RNCP","LISTE_IDEO"))
  )  %>% 
  filter(!(is.na(code_certification_possible)&appariement=="inverse")) 


#Ce bloc :
#   1- Joint les données Parcoursup avec la table des correspondances possibles (format long),
#   2- Réévalue l’appariement en fonction du type de formation (scolaire/apprentissage),
#   3- Repriorise les formats CFD ou MEFSTAT11 selon les cas,
#   4- Formate les colonnes pour standardisation.

parcoursup_param_code_certification_init <- parcoursup_catalogue_init_simpli_long %>% 
  left_join(parcoursup_nomenclature_de_ref_correspondance_code_certification_ensemble_codes_possibles_long,
            relationship = "many-to-many",
            by=c("type_certification","code_certification"))  %>% 
  mutate(
    appariement=case_when(
      APPRENTISSAGEOUSCOLAIRE=="Apprentissage" & str_detect(code_certification_possible,"CFD:")~"normal",
      APPRENTISSAGEOUSCOLAIRE=="Apprentissage" & str_detect(code_certification_possible,"MEFSTAT11:")~"inverse",
      APPRENTISSAGEOUSCOLAIRE=="Scolaire" & str_detect(code_certification_possible,"CFD:")~"inverse",
      APPRENTISSAGEOUSCOLAIRE=="Scolaire" & str_detect(code_certification_possible,"MEFSTAT11:")~"normal",
      T~appariement
    )
  ) %>%
  mutate(
    appariement=factor(appariement,levels=c("normal","inverse")),
    type_certification=factor(type_certification,levels=c("CODECFD","CODEMEF","CODESISE","ID_RCO","LISTE_RNCP","LISTE_IDEO"))
  ) %>% 
  select(-APPRENTISSAGEOUSCOLAIRE) 



# Ce bloc :
#     1- Rassemble toutes les correspondances associées à chaque ligne de formation (CODEFORMATIONACCUEIL),
#     2- Les structure selon deux axes : 
#           - appariement: normal vs inverse
#           - anciennete: self, nouveau, ancien
#           
# Le résultat est une table multi-niveaux imbriquée, prête à être utilisée dans des applications ou outils de contrôle.
# Cette table pourra être exportée au format json ou rds: jsonlite::write_json(parcoursup_param,"parcoursup_param.json")

parcoursup_param <- parcoursup_catalogue_init %>% 
  left_join(
    parcoursup_param_code_certification_init %>% 
      select(-code_certification) %>% 
      pivot_wider(names_from = appariement,values_from = code_certification_possible) %>% 
      group_by(CODEFORMATIONACCUEIL,anciennete_certification_ci) %>%
      nest(.key = "code_certification_possible") %>% 
      pivot_wider(names_from = anciennete_certification_ci ,values_from = code_certification_possible),
    by="CODEFORMATIONACCUEIL"
  ) 



