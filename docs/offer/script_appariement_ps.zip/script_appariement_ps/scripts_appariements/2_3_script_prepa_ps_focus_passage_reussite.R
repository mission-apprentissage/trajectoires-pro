# Script d'appariement des formations Parcoursup aux données de de réussite et passage traitées par la DEPP et le SIES 
# 
# Ce script vise à apparier les formations de Parcoursup avec les données de réussite et de passage 
# du SIES (Système d'Information sur l'Enseignement Supérieur).
# 
# Il permet de croiser les taux de réussite et de passage avec les formations Parcoursup, 
# en utilisant les codes SISE et d'autres sources de certification.

## Données du SIES taux de reussite & taux de passage ----
# Import des taux de réussite et passage

sies_LG_reussite_passage_uai_composante <- read_excel(file.path(chemin_racine_data,"SSM/SIES/2025/reussite_passage/LG_coh19et22_uai_composante.xlsx"))
sies_LG_reussite_passage_uai_principal <- read_excel(file.path(chemin_racine_data,"SSM/SIES/2025/reussite_passage/LG_coh19et22_uai_principal.xlsx"))

### Construction du catalogue final des formations Parcoursup ----

parcoursup_prepa_reussite_passage <- parcoursup_param %>% 
  pivot_longer(cols = intersect(names(.),c("ancien","self","nouveau")),names_to = "anciennete_certification_ci" ,values_to ="code_certification_possible") %>% 
  unnest("code_certification_possible") %>% 
  pivot_longer(cols = intersect(names(.),c("normal","inverse")),names_to = "appariement" ,values_to ="code_certification_possible") %>% 
  filter(!is.na(code_certification_possible)) %>% 
  select(UAI_GES,UAI_AFF,UAI_COMPOSANTE,CODEFORMATIONACCUEIL,code_certification_possible,appariement,type_certification,validite_code_certification,anciennete_certification_ci) %>%   
  pivot_longer(cols = contains("UAI"),names_to = "type_uai",values_to = "uai") %>% 
  select(type_uai,uai,everything())  %>% 
  left_join(
    ACCE_UAI_MERE %>% 
      distinct(numero_uai_trouve,numero_uai_mere),
    by=c("uai"="numero_uai_trouve")
  ) %>% 
  pivot_longer(cols=c(uai,numero_uai_mere),values_to = "uai",names_to = "fille_mere_uai") %>% 
  drop_na(uai) %>% 
  mutate(
    appariement=factor(appariement,levels=c("normal","inverse")),
    anciennete_certification_ci=factor(anciennete_certification_ci,levels=c("self","nouveau","ancien")),
    type_uai=ifelse(fille_mere_uai=="numero_uai_mere",paste0(type_uai,"_MERE") ,type_uai),
    type_uai=factor(type_uai,levels=c("UAI_COMPOSANTE","UAI_AFF","UAI_GES","UAI_COMPOSANTE_MERE","UAI_AFF_MERE","UAI_GES_MERE"))
  ) %>% 
  select(-fille_mere_uai) 


### Préparation des données SIES (Réussite et Passage) ----
# On crée deux bases pour les UAI de composante et principal, et on associe les codes SISE.

sies_LG_reussite_passage_uai_composante <- sies_LG_reussite_passage_uai_composante %>% 
  mutate(type_uai="composante",
         code_certification=paste0("SISE:",diplom)
  )%>% 
  select(-diplom) %>% 
  setNames(c("uai","taux_de_reussite_19","taux_de_passage_22","type_uai_sies","code_certification"))

sies_LG_reussite_passage_uai_principal <- sies_LG_reussite_passage_uai_principal %>% 
  mutate(type_uai="principal",
         code_certification=paste0("SISE:",diplom)
  ) %>% 
  select(-diplom) %>% 
  setNames(c("uai","taux_de_reussite_19","taux_de_passage_22","type_uai_sies","code_certification"))

sies_LG_reussite_passage_uai_ensemble <- sies_LG_reussite_passage_uai_composante %>% 
  bind_rows(sies_LG_reussite_passage_uai_principal) %>% 
  distinct() %>% 
  mutate(type_uai_sies=factor(type_uai_sies,levels = c("composante","principal")))


### Appariement des formations Parcoursup avec les données SIES ----

parcoursup_prepa_reussite_passage_couvert <- parcoursup_prepa_reussite_passage %>% 
  inner_join(
    sies_LG_reussite_passage_uai_ensemble,
    by=c("uai","code_certification_possible"="code_certification")
  ) %>% 
  group_by(CODEFORMATIONACCUEIL) %>%
  filter(as.numeric(type_uai)==min(as.numeric(type_uai))) %>% 
  ungroup() %>% 
  select(-type_uai,-uai) %>% 
  distinct() %>% 
  group_by(CODEFORMATIONACCUEIL) %>%
  filter(as.numeric(appariement)==min(as.numeric(appariement))) %>% 
  ungroup() %>%
  distinct() %>% 
  group_by(CODEFORMATIONACCUEIL) %>%
  filter(as.numeric(type_certification)==min(as.numeric(type_certification))) %>% 
  ungroup() %>%
  distinct() %>% 
  group_by(CODEFORMATIONACCUEIL) %>%
  filter(as.numeric(anciennete_certification_ci)==min(as.numeric(anciennete_certification_ci))) %>% 
  ungroup() %>%
  distinct() %>% 
  group_by(CODEFORMATIONACCUEIL) %>%
  mutate(
    Couverture=case_when(
      n() > 1 ~"Non couvert - Plusieurs codes certification associés",
      is.na(taux_de_reussite_19)&is.na(taux_de_passage_22)~ "Non couvert",
      T~"Couvert")
  ) %>% 
  ungroup() %>% 
  select(-validite_code_certification,-type_uai_sies,-anciennete_certification_ci) 



parcoursup_prepa_reussite_passage_non_couvert <- parcoursup_catalogue_init %>% 
  anti_join(
    parcoursup_prepa_reussite_passage_couvert %>% 
      ungroup() %>%
      distinct(CODEFORMATIONACCUEIL,Couverture),
    by="CODEFORMATIONACCUEIL"
  ) %>% 
  left_join(
    parcoursup_param_code_certification_init %>% 
      mutate(validite_code_certification=factor(validite_code_certification,levels=c("Valide","Non valide - Plusieurs codes certification associés","Non valide - Code inconnu"))) %>% 
      group_by(CODEFORMATIONACCUEIL) %>%
      filter(as.numeric(validite_code_certification)==min(as.numeric(validite_code_certification))) %>% 
      distinct(CODEFORMATIONACCUEIL,validite_code_certification) ,
    by="CODEFORMATIONACCUEIL"
  ) %>% 
  left_join(
    ACCE_UAI %>% 
      distinct(numero_uai,academie),
    by=c("UAI_AFF"="numero_uai")
  ) %>% 
  mutate(
    Couverture=case_when(
      !CODECFD %in% c(certifications_normalement_disponibles,NA) ~ "Non couvert - Nouvelle formation",
      str_sub(academie,1,1)=="4" ~ "Non couvert - Territoire mal couvert",  
      !(UAI_GES %in% ACCE_UAI$numero_uai & UAI_AFF  %in% ACCE_UAI$numero_uai & UAI_COMPOSANTE  %in% ACCE_UAI$numero_uai) ~"Non couvert - UAI Inconnu",
      validite_code_certification=="Valide" ~ "Non couvert - Sans raison évidente",
      validite_code_certification=="Non valide - Plusieurs codes certification associés" ~ "Non couvert - Plusieurs formations en annéee terminale associées",
      validite_code_certification=="Non valide - Code inconnu" ~ "Non couvert - code certification inconnu",
      !(is.na(CODEMEF)& is.na(CODECFD) & is.na(CODESISE) & is.na(LISTE_IDEO) & is.na(ID_RCO) & is.na(LISTE_RNCP)) ~ "Non couvert - code certification inconnu",
      T ~ "Non couvert - code certification absent"
    )
  ) %>% 
  select(-validite_code_certification)


parcoursup_reussite_passage <- parcoursup_prepa_reussite_passage_couvert %>%  
  mutate_at(vars(taux_de_reussite_19 ,taux_de_passage_22 ),~ifelse(Couverture!="Couvert",NA,.)) %>%  
  group_by(CODEFORMATIONACCUEIL) %>% 
  mutate(code_certification_possible=ifelse(Couverture=="Non couvert - Plusieurs codes certification associés",paste0(code_certification_possible,collapse = ";",sep=""),code_certification_possible)) %>% 
  ungroup() %>% 
  distinct(CODEFORMATIONACCUEIL,Couverture,code_certification_possible,taux_de_reussite_19 ,taux_de_passage_22 ) %>%   
  bind_rows(
    parcoursup_prepa_reussite_passage_non_couvert %>% 
      distinct(CODEFORMATIONACCUEIL,Couverture)
  ) %>% 
  select(CODEFORMATIONACCUEIL,code_certification_possible,taux_de_reussite_19 ,taux_de_passage_22,Couverture ) %>%  
  rename(
    code_certification_sies=code_certification_possible,
    Couverture_sies=Couverture
  )
