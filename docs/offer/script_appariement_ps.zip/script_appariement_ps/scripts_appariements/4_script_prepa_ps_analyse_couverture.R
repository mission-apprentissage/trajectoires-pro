# Script d'analyse de la couverture des formations Parcoursup
# 
# Ce script vise à analyser la couverture des formations présentes dans Parcoursup. 
# Il fournit une analyse quantitative de la couverture des formations.
# 
# Les données préparées dans ce script serviront à générer un document de suivi de la couverture des formations,
# disponible à l'adresse suivante : https://mission-apprentissage.github.io/trajectoires-pro/analyse/couverture_catalogue/parcoursup/parcoursup_campagne_2025.html

### Calcul de la couverture des formations Parcoursup ----
# Sélection des formations paramétrées dans Parcoursup et classification par type de diplôme

stats_catalogue_parcoursup_couverture <- parcoursup_catalogue_final %>% 
  filter(FORMATION_PARAMÉTRÉE=="Paramétrée")  %>%
  mutate(
    `Type diplôme`=case_when(
      str_sub(LIBFORMATION,1,2)=="LP"~"Licence professionnelle",
      str_sub(LIBFORMATION,1,7)=="Licence"~"Licence générale",
      CODEFORMATION==24 & str_detect(LIBSPÉCIALITÉ,"Bac \\+ 5")~"Formation des écoles de commerce et de management Bac + 5",
      CODEFORMATION==24 & str_detect(LIBSPÉCIALITÉ,"Bac \\+ 3")~"Formation des écoles de commerce et de management Bac + 3",
      T~LIBFORMATION
    ),
    `Type diplôme`=str_to_upper(`Type diplôme`),
    Filiere=ifelse(APPRENTISSAGEOUSCOLAIRE=="Scolaire","Sco.","App.")
  ) %>% 
  left_join(
    correspondance_formation_scope_exposition %>% 
      mutate(
        `Type diplôme`=str_to_upper(`Type diplôme`) 
      ),
    by=c("Filiere","Type diplôme")
  ) %>% 
  group_by(`Type diplôme`,Filiere,`Scope campagne 2025`,Couverture_insertion) %>% 
  summarise(nb=n()) %>% 
  pivot_wider(names_from = Couverture_insertion,values_from = nb) %>% 
  mutate_all(replace_na,0) %>% 
  rowwise() %>% 
  mutate(
    `Non couvert`=sum(c_across(contains("Non couvert")))
  ) %>% 
  ungroup() %>% 
  setNames(c("Type diplôme","Filiere","Scope campagne 2025",paste0(setdiff(names(.),c("Type diplôme","Filiere","Scope campagne 2025"))," (nb)"))) %>% 
  select(
    c("Type diplôme",
      "Filiere", 
      "Scope campagne 2025",
      "Couvert (nb)",
      "Non couvert (nb)",
      "Non couvert - Sous le seuil de 20 élèves (nb)",
      "Non couvert - Nouvelle formation (nb)", 
      "Non couvert - code certification inconnu (nb)",
      "Non couvert - UAI Inconnu (nb)",
      "Non couvert - Territoire mal couvert (nb)",
      "Non couvert - Plusieurs formations en annéee terminale associées (nb)",
      # "Non couvert - Plusieurs certifications associées au départ dont une seule est couverte (nb)",
      "Non couvert - Sans raison évidente (nb)" )
  ) %>% 
  left_join(
    parcoursup_catalogue_final %>% 
      filter(FORMATION_PARAMÉTRÉE=="Paramétrée")  %>%
      mutate(
        `Type diplôme`=case_when(
          str_sub(LIBFORMATION,1,2)=="LP"~"Licence professionnelle",
          str_sub(LIBFORMATION,1,7)=="Licence"~"Licence générale",
          CODEFORMATION==24 & str_detect(LIBSPÉCIALITÉ,"Bac \\+ 5")~"Formation des écoles de commerce et de management Bac + 5",
          CODEFORMATION==24 & str_detect(LIBSPÉCIALITÉ,"Bac \\+ 3")~"Formation des écoles de commerce et de management Bac + 3",
          T~LIBFORMATION
        ),
        
        `Type diplôme`=str_to_upper(`Type diplôme`),
        Filiere=ifelse(APPRENTISSAGEOUSCOLAIRE=="Scolaire","Sco.","App.")
      ) %>% 
      left_join(
        correspondance_formation_scope_exposition %>% 
          mutate(
            `Type diplôme`=str_to_upper(`Type diplôme`) 
          ),
        by=c("Filiere","Type diplôme")
      ) %>% 
      group_by(`Type diplôme`,Filiere,`Scope campagne 2025`,Couverture_insertion) %>% 
      summarise(part=n()) %>% 
      mutate(part=prop.table(part)) %>% 
      pivot_wider(names_from = Couverture_insertion,values_from = part) %>% 
      mutate_all(replace_na,0) %>% 
      rowwise() %>% 
      mutate(
        `Non couvert`=sum(c_across(contains("Non couvert")))
      ) %>% 
      ungroup() %>% 
      setNames(c("Type diplôme","Filiere","Scope campagne 2025",paste0(setdiff(names(.),c("Type diplôme","Filiere","Scope campagne 2025"))," (%)")))  %>% 
      select(
        c("Type diplôme",
          "Filiere", 
          "Scope campagne 2025",
          "Couvert (%)",
          "Non couvert (%)",
          "Non couvert - Sous le seuil de 20 élèves (%)",
          "Non couvert - Nouvelle formation (%)", 
          "Non couvert - code certification inconnu (%)",
          "Non couvert - UAI Inconnu (%)",
          "Non couvert - Territoire mal couvert (%)",
          "Non couvert - Plusieurs formations en annéee terminale associées (%)",
          # "Non couvert - Plusieurs certifications associées au départ dont une seule est couverte (%)",
          "Non couvert - Sans raison évidente (%)" )
      ),
    by=c("Type diplôme","Filiere","Scope campagne 2025")
  ) %>% 
  select(
    c("Type diplôme",
      "Filiere", 
      "Scope campagne 2025",
      "Couvert (nb)",
      "Couvert (%)",
      "Non couvert (nb)",
      "Non couvert (%)",
      "Non couvert - Sous le seuil de 20 élèves (nb)",
      "Non couvert - Sous le seuil de 20 élèves (%)",
      "Non couvert - Nouvelle formation (nb)", 
      "Non couvert - Nouvelle formation (%)", 
      "Non couvert - code certification inconnu (nb)",
      "Non couvert - code certification inconnu (%)",
      "Non couvert - UAI Inconnu (nb)",
      "Non couvert - UAI Inconnu (%)",
      "Non couvert - Territoire mal couvert (nb)",
      "Non couvert - Territoire mal couvert (%)",
      "Non couvert - Plusieurs formations en annéee terminale associées (nb)",
      "Non couvert - Plusieurs formations en annéee terminale associées (%)",
      # "Non couvert - Plusieurs certifications associées au départ dont une seule est couverte (nb)",
      # "Non couvert - Plusieurs certifications associées au départ dont une seule est couverte (%)",
      "Non couvert - Sans raison évidente (nb)",
      "Non couvert - Sans raison évidente (%)"
    )
  ) 

### Ajout des proportions par catégorie de couverture ----
# Transformation en pourcentages des différentes catégories de couverture

stats_catalogue_parcoursup_2025<- NULL

stats_catalogue_parcoursup_2025$stats_catalogue_partenaire <- parcoursup_catalogue_final %>% 
  filter(FORMATION_PARAMÉTRÉE=="Paramétrée")  %>%
  mutate(
    `Type diplôme`=case_when(
      str_sub(LIBFORMATION,1,2)=="LP"~"Licence professionnelle",
      str_sub(LIBFORMATION,1,7)=="Licence"~"Licence générale",
      CODEFORMATION==24 & str_detect(LIBSPÉCIALITÉ,"Bac \\+ 5")~"Formation des écoles de commerce et de management Bac + 5",
      CODEFORMATION==24 & str_detect(LIBSPÉCIALITÉ,"Bac \\+ 3")~"Formation des écoles de commerce et de management Bac + 3",
      T~LIBFORMATION
    ),
    `Type diplôme`=str_to_upper(`Type diplôme`),
    Filiere=ifelse(APPRENTISSAGEOUSCOLAIRE=="Scolaire","Sco.","App.")
  ) %>% 
  left_join(
    correspondance_formation_scope_exposition %>% 
      mutate(
        `Type diplôme`=str_to_upper(`Type diplôme`) 
      ),
    by=c("Filiere","Type diplôme")
  ) %>% 
  group_by(`Type diplôme`,Filiere,`Scope campagne 2025`) %>% 
  summarise("Nombre de formations"=n()) %>% 
  ungroup() %>% 
  mutate("Part du  catalogue"=prop.table(`Nombre de formations`)) %>% 
  left_join(stats_catalogue_parcoursup_couverture,
            by=c("Type diplôme","Filiere","Scope campagne 2025"))




stats_catalogue_parcoursup_2025$stats_catalogue_partenaire <- stats_catalogue_parcoursup_2025$stats_catalogue_partenaire %>% 
  bind_rows(
    stats_catalogue_parcoursup_2025$stats_catalogue_partenaire %>% 
      summarise_if(is.numeric,sum,na.rm=T) %>% 
      mutate(
        `Type diplôme`="Total",
        Filiere="Total",
        `Scope campagne 2025`="Total" ,
        `Couvert (%)`=`Couvert (nb)`/`Nombre de formations`, 
        `Non couvert (%)`=`Non couvert (nb)`/`Nombre de formations`, 
        `Non couvert - Sous le seuil de 20 élèves (%)`=`Non couvert - Sous le seuil de 20 élèves (nb)`/`Nombre de formations`, 
        `Non couvert - Nouvelle formation (%)`=`Non couvert - Nouvelle formation (nb)`/`Nombre de formations`, 
        `Non couvert - code certification inconnu (%)`=`Non couvert - code certification inconnu (nb)`/`Nombre de formations`, 
        `Non couvert - UAI Inconnu (%)`=`Non couvert - UAI Inconnu (nb)`/`Nombre de formations`, 
        `Non couvert - Territoire mal couvert (%)`=`Non couvert - Territoire mal couvert (nb)`/`Nombre de formations`, 
        `Non couvert - Plusieurs formations en annéee terminale associées (%)`=`Non couvert - Plusieurs formations en annéee terminale associées (nb)`/`Nombre de formations`,
        # `Non couvert - Plusieurs certifications associées au départ dont une seule est couverte (%)`=`Non couvert - Plusieurs certifications associées au départ dont une seule est couverte (nb)`/`Nombre de formations`,
        `Non couvert - Sans raison évidente (%)`=`Non couvert - Sans raison évidente (nb)`/`Nombre de formations`
      )    
  )




### Synthèse des statistiques de couverture ----
# Regroupement des statistiques sur la couverture des formations par campagne

stats_catalogue_parcoursup_couverture_synthese <- parcoursup_catalogue_final %>% 
  filter(FORMATION_PARAMÉTRÉE=="Paramétrée")  %>%
  mutate(
    `Type diplôme`=case_when(
      str_sub(LIBFORMATION,1,2)=="LP"~"Licence professionnelle",
      str_sub(LIBFORMATION,1,7)=="Licence"~"Licence générale",
      CODEFORMATION==24 & str_detect(LIBSPÉCIALITÉ,"Bac \\+ 5")~"Formation des écoles de commerce et de management Bac + 5",
      CODEFORMATION==24 & str_detect(LIBSPÉCIALITÉ,"Bac \\+ 3")~"Formation des écoles de commerce et de management Bac + 3",
      T~LIBFORMATION
    ),
    `Type diplôme`=str_to_upper(`Type diplôme`),
    Filiere=ifelse(APPRENTISSAGEOUSCOLAIRE=="Scolaire","Sco.","App.")
  ) %>% 
  left_join(
    correspondance_formation_scope_exposition %>% 
      mutate(
        `Type diplôme`=str_to_upper(`Type diplôme`) 
      ),
    by=c("Filiere","Type diplôme")
  ) %>% 
  group_by(`Scope campagne 2025`,Couverture_insertion) %>% 
  summarise(nb=n()) %>% 
  pivot_wider(names_from = Couverture_insertion,values_from = nb) %>% 
  mutate_all(replace_na,0) %>% 
  rowwise() %>% 
  mutate(
    `Non couvert`=sum(c_across(contains("Non couvert")))
  ) %>% 
  ungroup() %>% 
  setNames(c("Scope campagne 2025",paste0(setdiff(names(.),c("Scope campagne 2025"))," (nb)"))) %>% 
  select(
    c("Scope campagne 2025",
      "Couvert (nb)",
      "Non couvert (nb)",
      "Non couvert - Sous le seuil de 20 élèves (nb)",
      "Non couvert - Nouvelle formation (nb)", 
      "Non couvert - code certification inconnu (nb)",
      "Non couvert - UAI Inconnu (nb)",
      "Non couvert - Territoire mal couvert (nb)",
      "Non couvert - Plusieurs formations en annéee terminale associées (nb)",
      # "Non couvert - Plusieurs certifications associées au départ dont une seule est couverte (nb)",
      "Non couvert - Sans raison évidente (nb)" )
  ) %>% 
  left_join(
    parcoursup_catalogue_final %>% 
      filter(FORMATION_PARAMÉTRÉE=="Paramétrée")  %>%
      mutate(
        `Type diplôme`=case_when(
          str_sub(LIBFORMATION,1,2)=="LP"~"Licence professionnelle",
          str_sub(LIBFORMATION,1,7)=="Licence"~"Licence générale",
          CODEFORMATION==24 & str_detect(LIBSPÉCIALITÉ,"Bac \\+ 5")~"Formation des écoles de commerce et de management Bac + 5",
          CODEFORMATION==24 & str_detect(LIBSPÉCIALITÉ,"Bac \\+ 3")~"Formation des écoles de commerce et de management Bac + 3",
          T~LIBFORMATION
        ),
        `Type diplôme`=str_to_upper(`Type diplôme`),
        Filiere=ifelse(APPRENTISSAGEOUSCOLAIRE=="Scolaire","Sco.","App.")
      ) %>% 
      left_join(
        correspondance_formation_scope_exposition %>% 
          mutate(
            `Type diplôme`=str_to_upper(`Type diplôme`) 
          ),
        by=c("Filiere","Type diplôme")
      ) %>% 
      group_by(`Scope campagne 2025`,Couverture_insertion) %>% 
      summarise(part=n()) %>% 
      mutate(part=prop.table(part)) %>% 
      pivot_wider(names_from = Couverture_insertion,values_from = part) %>% 
      mutate_all(replace_na,0) %>% 
      rowwise() %>% 
      mutate(
        `Non couvert`=sum(c_across(contains("Non couvert")))
      ) %>% 
      ungroup() %>% 
      setNames(c("Scope campagne 2025",paste0(setdiff(names(.),c("Scope campagne 2025"))," (%)")))  %>% 
      select(
        c( 
          "Scope campagne 2025",
          "Couvert (%)",
          "Non couvert (%)",
          "Non couvert - Sous le seuil de 20 élèves (%)",
          "Non couvert - Nouvelle formation (%)", 
          "Non couvert - code certification inconnu (%)",
          "Non couvert - UAI Inconnu (%)",
          "Non couvert - Territoire mal couvert (%)",
          "Non couvert - Plusieurs formations en annéee terminale associées (%)",
          # "Non couvert - Plusieurs certifications associées au départ dont une seule est couverte (%)",
          "Non couvert - Sans raison évidente (%)" )
      ),
    by=c("Scope campagne 2025")
  ) %>% 
  select(
    c(
      "Scope campagne 2025",
      "Couvert (nb)",
      "Couvert (%)",
      "Non couvert (nb)",
      "Non couvert (%)",
      "Non couvert - Sous le seuil de 20 élèves (nb)",
      "Non couvert - Sous le seuil de 20 élèves (%)",
      "Non couvert - Nouvelle formation (nb)", 
      "Non couvert - Nouvelle formation (%)", 
      "Non couvert - code certification inconnu (nb)",
      "Non couvert - code certification inconnu (%)",
      "Non couvert - UAI Inconnu (nb)",
      "Non couvert - UAI Inconnu (%)",
      "Non couvert - Territoire mal couvert (nb)",
      "Non couvert - Territoire mal couvert (%)",
      "Non couvert - Plusieurs formations en annéee terminale associées (nb)",
      "Non couvert - Plusieurs formations en annéee terminale associées (%)",
      # "Non couvert - Plusieurs certifications associées au départ dont une seule est couverte (nb)",
      # "Non couvert - Plusieurs certifications associées au départ dont une seule est couverte (%)",
      "Non couvert - Sans raison évidente (nb)",
      "Non couvert - Sans raison évidente (%)"
    )
  ) 

stats_catalogue_parcoursup_campagne_2025_synthese <- NULL

stats_catalogue_parcoursup_campagne_2025_synthese$stats_catalogue_partenaire  <- parcoursup_catalogue_final %>% 
  filter(FORMATION_PARAMÉTRÉE=="Paramétrée")  %>%
  mutate(
    `Type diplôme`=case_when(
      str_sub(LIBFORMATION,1,2)=="LP"~"Licence professionnelle",
      str_sub(LIBFORMATION,1,7)=="Licence"~"Licence générale",
      CODEFORMATION==24 & str_detect(LIBSPÉCIALITÉ,"Bac \\+ 5")~"Formation des écoles de commerce et de management Bac + 5",
      CODEFORMATION==24 & str_detect(LIBSPÉCIALITÉ,"Bac \\+ 3")~"Formation des écoles de commerce et de management Bac + 3",
      T~LIBFORMATION
    ),
    `Type diplôme`=str_to_upper(`Type diplôme`),
    Filiere=ifelse(APPRENTISSAGEOUSCOLAIRE=="Scolaire","Sco.","App.")
  ) %>% 
  left_join(
    correspondance_formation_scope_exposition %>% 
      mutate(
        `Type diplôme`=str_to_upper(`Type diplôme`) 
      ),
    by=c("Filiere","Type diplôme")
  ) %>% 
  group_by(`Scope campagne 2025`) %>% 
  summarise("Nombre de formations"=n()) %>% 
  ungroup() %>% 
  mutate("Part du  catalogue"=prop.table(`Nombre de formations`)) %>%   
  left_join(stats_catalogue_parcoursup_couverture_synthese,
            by=c("Scope campagne 2025"))








stats_catalogue_parcoursup_campagne_2025_synthese$stats_catalogue_partenaire  <- stats_catalogue_parcoursup_campagne_2025_synthese$stats_catalogue_partenaire  %>% 
  bind_rows(  stats_catalogue_parcoursup_campagne_2025_synthese$stats_catalogue_partenaire  %>% 
                summarise_if(is.numeric,sum,na.rm=T) %>% 
                mutate(
                  `Scope campagne 2025`="Ensemble catalogue",
                  `Scope campagne 2025`, 
                  `Couvert (%)`=`Couvert (nb)`/`Nombre de formations`, 
                  `Non couvert (%)`=`Non couvert (nb)`/`Nombre de formations`, 
                  `Non couvert - Sous le seuil de 20 élèves (%)`=`Non couvert - Sous le seuil de 20 élèves (nb)`/`Nombre de formations`, 
                  `Non couvert - Nouvelle formation (%)`=`Non couvert - Nouvelle formation (nb)`/`Nombre de formations`, 
                  `Non couvert - code certification inconnu (%)`=`Non couvert - code certification inconnu (nb)`/`Nombre de formations`, 
                  `Non couvert - UAI Inconnu (%)`=`Non couvert - UAI Inconnu (nb)`/`Nombre de formations`, 
                  `Non couvert - Territoire mal couvert (%)`=`Non couvert - Territoire mal couvert (nb)`/`Nombre de formations`, 
                  `Non couvert - Plusieurs formations en annéee terminale associées (%)`=`Non couvert - Plusieurs formations en annéee terminale associées (nb)`/`Nombre de formations`,
                  # `Non couvert - Plusieurs certifications associées au départ dont une seule est couverte (%)`=`Non couvert - Plusieurs certifications associées au départ dont une seule est couverte (nb)`/`Nombre de formations`,
                  `Non couvert - Sans raison évidente (%)`=`Non couvert - Sans raison évidente (nb)`/`Nombre de formations`
                )   
  )

### Impact des traitements API et appariements sur la couverture ----
#### Analyse de l'amélioration de la couverture suite à l'utilisation de l'API----

donnees_insertion <- ensemble_data_formationsStats %>% 
  filter(Couverture=="Couvert") %>%
  distinct(id_unique,filiere) %>% 
  mutate(
    code_certification=str_split_fixed(id_unique,"_",n=3)[,1],
    UAI=str_split_fixed(id_unique,"_",n=3)[,2],
    code_certification=case_when(
      filiere=="pro" ~ paste0("MEFSTAT11:",code_certification),
      filiere=="apprentissage" ~ paste0("CFD:",code_certification),
      filiere=="superieur" ~ paste0("SISE:",code_certification)
    ),
    code_certification_premiere_annee=case_when(
      filiere=="pro" ~ paste0(str_sub(code_certification,1,13),1,str_sub(code_certification,15,21)),
      T~code_certification
    )
  )  %>% 
  select(UAI,code_certification,code_certification_premiere_annee,filiere)


couverture_initiale_parcoursup_catalogue_final <- parcoursup_catalogue_final %>% 
  pivot_longer(cols=contains("UAI"),values_to = "uai",names_to = "type_uai") %>% 
  left_join(
    n_mef %>% 
      select(MEF,MEF_STAT_11),
    by=c("CODEMEF"="MEF")
  ) %>% 
  select(CODEFORMATIONACCUEIL,uai,MEF_STAT_11,CODECFD,CODESISE,APPRENTISSAGEOUSCOLAIRE) %>% 
  mutate(code_certification=case_when(
    !is.na(CODESISE)~paste0("SISE:",CODESISE),
    APPRENTISSAGEOUSCOLAIRE=="Scolaire"~paste0("MEFSTAT11:",MEF_STAT_11),
    APPRENTISSAGEOUSCOLAIRE=="Apprentissage"~paste0("CFD:",CODECFD)
  )
  ) %>% 
  filter(!is.na(code_certification)) %>% 
  select(CODEFORMATIONACCUEIL,uai,code_certification) %>% 
  anti_join(
    donnees_insertion,
    by=c("uai"="UAI","code_certification"="code_certification_premiere_annee")) %>% 
  distinct(CODEFORMATIONACCUEIL) %>% 
  mutate(Couverture="Non couvert") %>% 
  bind_rows(
    parcoursup_catalogue_final %>% 
      pivot_longer(cols=contains("UAI"),values_to = "uai",names_to = "type_uai") %>% 
      left_join(
        n_mef %>% 
          select(MEF,MEF_STAT_11),
        by=c("CODEMEF"="MEF")
      ) %>% 
      select(CODEFORMATIONACCUEIL,uai,MEF_STAT_11,CODECFD,CODESISE,APPRENTISSAGEOUSCOLAIRE) %>% 
      mutate(code_certification=case_when(
        !is.na(CODESISE)~paste0("SISE:",CODESISE),
        APPRENTISSAGEOUSCOLAIRE=="Scolaire"~paste0("MEFSTAT11:",MEF_STAT_11),
        APPRENTISSAGEOUSCOLAIRE=="Apprentissage"~paste0("CFD:",CODECFD)
      )
      ) %>% 
      filter(!is.na(code_certification)) %>% 
      select(CODEFORMATIONACCUEIL,uai,code_certification) %>% 
      inner_join(
        donnees_insertion,
        by=c("uai"="UAI","code_certification"="code_certification_premiere_annee")) %>% 
      distinct(CODEFORMATIONACCUEIL) %>% 
      mutate(Couverture="Couvert")
    
  ) %>% 
  mutate(Couverture=factor(Couverture,levels=c("Couvert","Non couvert"))) %>% 
  group_by(CODEFORMATIONACCUEIL) %>% 
  filter(as.numeric(Couverture)==min(as.numeric(Couverture))) %>% 
  ungroup() %>% 
  distinct() %>% 
  rename(Couverture_insertion_avant_api=Couverture)

#### Analyse de l'amélioration de la couverture suite aux appariements ----

parcoursup_catalogue_Couverture_insertion_avant_appariement <- parcoursup_catalogue_final %>% 
  select(CODEFORMATIONACCUEIL,contains("UAI"),CODEMEF,CODECFD,CODESISE,APPRENTISSAGEOUSCOLAIRE) %>% 
  left_join(
    n_mef %>% 
      select(MEF,MEF_STAT_11),
    by=c("CODEMEF"="MEF")
  ) %>% 
  mutate(
    code_certification_init=case_when(
      !is.na(CODESISE)~paste0("SISE:",CODESISE),
      APPRENTISSAGEOUSCOLAIRE == "Apprentissage" ~paste0("CFD:",CODECFD),
      APPRENTISSAGEOUSCOLAIRE == "Scolaire" ~paste0("MEFSTAT11:",MEF_STAT_11)
    )
  ) %>% 
  select(-CODEMEF,-CODECFD,-CODESISE,-APPRENTISSAGEOUSCOLAIRE,-MEF_STAT_11) %>% 
  pivot_longer(cols=contains("UAI"),values_to = "uai",names_to = "type_uai") %>% 
  mutate(
    type_uai=factor(type_uai,levels=c("UAI_COMPOSANTE","UAI_AFF","UAI_GES"))
  ) %>% 
  group_by(uai,code_certification_init,CODEFORMATIONACCUEIL) %>% 
  filter(as.numeric(type_uai)==min(as.numeric(type_uai))) %>% 
  left_join(
    ensemble_data_formationsStats %>% 
      select(code_certification,uai,Couverture,filiere) %>% 
      # mutate(
      #   code_certification=case_when(
      #     filiere == "superieur" ~paste0("SISE:",code_certification),
      #     filiere == "apprentissage" ~paste0("CFD:",code_certification),
      #     filiere == "pro" ~paste0("MEFSTAT11:",code_certification)
      #   )
      # ) %>% 
      select(-filiere),
    by=c("uai","code_certification_init"="code_certification")
  ) %>% 
  mutate(Couverture_insertion_avant_appariement=ifelse(is.na(Couverture),"Non couvert",Couverture)) %>% 
  select(-Couverture) %>% 
  mutate(Couverture_insertion_avant_appariement=factor(Couverture_insertion_avant_appariement,levels=c("Couvert","Sous le seuil de 20 élèves","Non couvert")))%>% 
  group_by(CODEFORMATIONACCUEIL) %>% 
  filter(as.numeric(Couverture_insertion_avant_appariement)==min(as.numeric(Couverture_insertion_avant_appariement))) %>% 
  filter(as.numeric(type_uai)==min(as.numeric(type_uai))) %>% 
  ungroup() %>% 
  select(CODEFORMATIONACCUEIL,Couverture_insertion_avant_appariement) %>% 
  mutate(
    Couverture_insertion_avant_appariement=as.character(Couverture_insertion_avant_appariement),
    Couverture_insertion_avant_appariement=ifelse(Couverture_insertion_avant_appariement=="Sous le seuil de 20 élèves","Non couvert - Sous le seuil de 20 élèves",Couverture_insertion_avant_appariement)) 

stats_parcoursup_catalogue_Couverture_insertion_avant_MIJ_synthese <- parcoursup_catalogue_final %>% 
  filter(FORMATION_PARAMÉTRÉE=="Paramétrée")  %>%
  mutate(
    `Type diplôme`=case_when(
      str_sub(LIBFORMATION,1,2)=="LP"~"Licence professionnelle",
      str_sub(LIBFORMATION,1,7)=="Licence"~"Licence générale",
      CODEFORMATION==24 & str_detect(LIBSPÉCIALITÉ,"Bac \\+ 5")~"Formation des écoles de commerce et de management Bac + 5",
      CODEFORMATION==24 & str_detect(LIBSPÉCIALITÉ,"Bac \\+ 3")~"Formation des écoles de commerce et de management Bac + 3",
      T~LIBFORMATION
    ),
    `Type diplôme`=str_to_upper(`Type diplôme`),
    Filiere=ifelse(APPRENTISSAGEOUSCOLAIRE=="Scolaire","Sco.","App.")
  ) %>% 
  left_join(
    correspondance_formation_scope_exposition %>% 
      mutate(
        `Type diplôme`=str_to_upper(`Type diplôme`) 
      ),
    by=c("Filiere","Type diplôme")
  ) %>% 
  left_join(
    couverture_initiale_parcoursup_catalogue_final,
    by="CODEFORMATIONACCUEIL"
  ) %>% 
  group_by(`Scope campagne 2025`,Couverture_insertion_avant_api) %>% 
  summarise(nb=n()) %>%  
  pivot_wider(names_from = Couverture_insertion_avant_api,values_from = nb) %>% 
  mutate_all(replace_na,0) %>% 
  rowwise()  %>% 
  mutate(
    `Non couvert`=sum(c_across(contains("Non couvert")))
  ) %>% 
  ungroup() %>% 
  setNames(c("Scope campagne 2025",paste0(setdiff(names(.),c("Scope campagne 2025"))," (nb)"))) %>% 
  select(
    c("Scope campagne 2025",
      "Couvert (nb)",
      "Non couvert (nb)" )
  ) %>% 
  left_join(
    parcoursup_catalogue_final %>% 
      filter(FORMATION_PARAMÉTRÉE=="Paramétrée")  %>%
      mutate(
        `Type diplôme`=case_when(
          str_sub(LIBFORMATION,1,2)=="LP"~"Licence professionnelle",
          str_sub(LIBFORMATION,1,7)=="Licence"~"Licence générale",
          CODEFORMATION==24 & str_detect(LIBSPÉCIALITÉ,"Bac \\+ 5")~"Formation des écoles de commerce et de management Bac + 5",
          CODEFORMATION==24 & str_detect(LIBSPÉCIALITÉ,"Bac \\+ 3")~"Formation des écoles de commerce et de management Bac + 3",
          T~LIBFORMATION
        ),
        `Type diplôme`=str_to_upper(`Type diplôme`),
        Filiere=ifelse(APPRENTISSAGEOUSCOLAIRE=="Scolaire","Sco.","App.")
      ) %>% 
      left_join(
        correspondance_formation_scope_exposition %>% 
          mutate(
            `Type diplôme`=str_to_upper(`Type diplôme`) 
          ),
        by=c("Filiere","Type diplôme")
      ) %>% 
      left_join(
        couverture_initiale_parcoursup_catalogue_final,
        by="CODEFORMATIONACCUEIL"
      ) %>% 
      group_by(`Scope campagne 2025`,Couverture_insertion_avant_api) %>% 
      summarise(part=n()) %>% 
      mutate(part=prop.table(part)) %>% 
      pivot_wider(names_from = Couverture_insertion_avant_api,values_from = part) %>% 
      mutate_all(replace_na,0) %>% 
      rowwise() %>% 
      mutate(
        `Non couvert`=sum(c_across(contains("Non couvert")))
      ) %>% 
      ungroup() %>% 
      setNames(c("Scope campagne 2025",paste0(setdiff(names(.),c("Scope campagne 2025"))," (%)")))  %>% 
      select(
        c( 
          "Scope campagne 2025",
          "Couvert (%)",
          "Non couvert (%)")
      ),
    by=c("Scope campagne 2025")
  ) %>% 
  select(
    c(
      "Scope campagne 2025",
      "Couvert (nb)",
      "Couvert (%)",
    )
  ) %>% 
  setNames(c(
    "Scope campagne 2025",
    "Couvert initialement (nb)",
    "Couvert initialement (%)"
  )) %>% 
  left_join(
    parcoursup_catalogue_final %>% 
      filter(FORMATION_PARAMÉTRÉE=="Paramétrée")  %>%
      mutate(
        `Type diplôme`=case_when(
          str_sub(LIBFORMATION,1,2)=="LP"~"Licence professionnelle",
          str_sub(LIBFORMATION,1,7)=="Licence"~"Licence générale",
          CODEFORMATION==24 & str_detect(LIBSPÉCIALITÉ,"Bac \\+ 5")~"Formation des écoles de commerce et de management Bac + 5",
          CODEFORMATION==24 & str_detect(LIBSPÉCIALITÉ,"Bac \\+ 3")~"Formation des écoles de commerce et de management Bac + 3",
          T~LIBFORMATION
        ),
        `Type diplôme`=str_to_upper(`Type diplôme`),
        Filiere=ifelse(APPRENTISSAGEOUSCOLAIRE=="Scolaire","Sco.","App.")
      ) %>% 
      left_join(
        correspondance_formation_scope_exposition %>% 
          mutate(
            `Type diplôme`=str_to_upper(`Type diplôme`) 
          ),
        by=c("Filiere","Type diplôme")
      ) %>% 
      left_join(
        parcoursup_catalogue_Couverture_insertion_avant_appariement,
        by="CODEFORMATIONACCUEIL"
      ) %>% 
      group_by(`Scope campagne 2025`,Couverture_insertion_avant_appariement) %>% 
      summarise(nb=n()) %>% 
      pivot_wider(names_from = Couverture_insertion_avant_appariement,values_from = nb) %>% 
      mutate_all(replace_na,0) %>% 
      rowwise()  %>% 
      mutate(
        `Non couvert`=sum(c_across(contains("Non couvert")))
      ) %>% 
      ungroup() %>% 
      setNames(c("Scope campagne 2025",paste0(setdiff(names(.),c("Scope campagne 2025"))," (nb)"))) %>% 
      select(
        c("Scope campagne 2025",
          "Couvert (nb)",
          "Non couvert (nb)" )
      ) %>% 
      left_join(
        parcoursup_catalogue_final %>% 
          filter(FORMATION_PARAMÉTRÉE=="Paramétrée")  %>%
          mutate(
            `Type diplôme`=case_when(
              str_sub(LIBFORMATION,1,2)=="LP"~"Licence professionnelle",
              str_sub(LIBFORMATION,1,7)=="Licence"~"Licence générale",
              CODEFORMATION==24 & str_detect(LIBSPÉCIALITÉ,"Bac \\+ 5")~"Formation des écoles de commerce et de management Bac + 5",
              CODEFORMATION==24 & str_detect(LIBSPÉCIALITÉ,"Bac \\+ 3")~"Formation des écoles de commerce et de management Bac + 3",
              T~LIBFORMATION
            ),
            `Type diplôme`=str_to_upper(`Type diplôme`),
            Filiere=ifelse(APPRENTISSAGEOUSCOLAIRE=="Scolaire","Sco.","App.")
          ) %>% 
          left_join(
            correspondance_formation_scope_exposition %>% 
              mutate(
                `Type diplôme`=str_to_upper(`Type diplôme`) 
              ),
            by=c("Filiere","Type diplôme")
          ) %>% 
          left_join(
            parcoursup_catalogue_Couverture_insertion_avant_appariement,
            by="CODEFORMATIONACCUEIL"
          ) %>% 
          group_by(`Scope campagne 2025`,Couverture_insertion_avant_appariement) %>% 
          summarise(part=n()) %>% 
          mutate(part=prop.table(part)) %>% 
          pivot_wider(names_from = Couverture_insertion_avant_appariement,values_from = part) %>% 
          mutate_all(replace_na,0) %>% 
          rowwise() %>% 
          mutate(
            `Non couvert`=sum(c_across(contains("Non couvert")))
          ) %>% 
          ungroup() %>% 
          setNames(c("Scope campagne 2025",paste0(setdiff(names(.),c("Scope campagne 2025"))," (%)")))  %>% 
          select(
            c( 
              "Scope campagne 2025",
              "Couvert (%)",
              "Non couvert (%)")
          ),
        by=c("Scope campagne 2025")
      ) %>% 
      select(
        c(
          "Scope campagne 2025",
          "Couvert (nb)",
          "Couvert (%)",
        )
      ) %>% 
      setNames(c(
        "Scope campagne 2025",
        "Couvert par api (nb)",
        "Couvert par api (%)"
      )),
    by="Scope campagne 2025"
  ) %>% 
  left_join(
    parcoursup_catalogue_final %>% 
      filter(FORMATION_PARAMÉTRÉE=="Paramétrée")  %>%
      mutate(
        `Type diplôme`=case_when(
          str_sub(LIBFORMATION,1,2)=="LP"~"Licence professionnelle",
          str_sub(LIBFORMATION,1,7)=="Licence"~"Licence générale",
          CODEFORMATION==24 & str_detect(LIBSPÉCIALITÉ,"Bac \\+ 5")~"Formation des écoles de commerce et de management Bac + 5",
          CODEFORMATION==24 & str_detect(LIBSPÉCIALITÉ,"Bac \\+ 3")~"Formation des écoles de commerce et de management Bac + 3",
          T~LIBFORMATION
        ),
        `Type diplôme`=str_to_upper(`Type diplôme`),
        Filiere=ifelse(APPRENTISSAGEOUSCOLAIRE=="Scolaire","Sco.","App.")
      ) %>% 
      left_join(
        correspondance_formation_scope_exposition %>% 
          mutate(
            `Type diplôme`=str_to_upper(`Type diplôme`) 
          ),
        by=c("Filiere","Type diplôme")
      ) %>% 
      left_join(
        couverture_initiale_parcoursup_catalogue_final,
        by="CODEFORMATIONACCUEIL"
      ) %>% 
      group_by(`Scope campagne 2025`) %>% 
      summarise("Nombre de formations"=n()) %>% 
      ungroup() %>% 
      mutate("Part du  catalogue"=prop.table(`Nombre de formations`)) %>%   
      left_join(stats_catalogue_parcoursup_couverture_synthese %>% 
                  select(`Scope campagne 2025`,`Couvert (nb)`,`Couvert (%)`),
                by=c("Scope campagne 2025")),
    by="Scope campagne 2025"
    
  ) %>% 
  select(
    "Scope campagne 2025",
    `Nombre de formations`,
    `Part du  catalogue`,
    everything()
  )  %>% 
  mutate(
    "Impact api (nb)"=`Couvert par api (nb)`-`Couvert initialement (nb)`,
    "Impact api (Pts)"=`Couvert par api (%)`-`Couvert initialement (%)`,
    "Impact appariement (nb)"=`Couvert (nb)`-`Couvert par api (nb)`,
    "Impact appariement (Pts)"=`Couvert (%)`-`Couvert par api (%)`,
    "Impact Global (nb)"=`Couvert (nb)`-`Couvert initialement (nb)`,
    "Impact Global (Pts)"=`Couvert (%)`-`Couvert initialement (%)`)

