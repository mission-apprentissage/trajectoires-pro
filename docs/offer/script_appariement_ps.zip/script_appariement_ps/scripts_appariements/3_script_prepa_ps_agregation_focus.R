parcoursup_catalogue_final <- parcoursup_catalogue_init %>% 
  left_join(
    parcoursup_insertion,
    by="CODEFORMATIONACCUEIL"
  ) %>% 
  left_join(
    parcoursup_remuneration,
    by="CODEFORMATIONACCUEIL"
  ) %>% 
  left_join(
    parcoursup_reussite_passage,
    by="CODEFORMATIONACCUEIL"
  )


