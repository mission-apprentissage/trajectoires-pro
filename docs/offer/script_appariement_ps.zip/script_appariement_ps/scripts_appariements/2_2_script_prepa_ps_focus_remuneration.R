# Script d'appariement des formations Parcoursup aux données de rémunération traitées par la DEPP et le SIES 
# 
# Ce script tente de faire correspondre les données de Parcoursup avec les données de la Depp
# Il explore plusieurs types d'appariements :
#   - normal: Basé sur les codes CFD et MEFSTAT11
#   - MNE: Basé sur la clé des ministères éducatifs
#   - Certif-Infos: Basé sur les codes Certif-Infos
#   - RNCP: Basé sur les codes RNCP
#   - IDEO: Basé sur les codes IDEO
# 

## Import des données de rémunération d'Exposition ----

url <- paste0(urls$exposition_ij[[choix_api_exposition]],"/api/inserjeunes/certifications?millesimes=2021&items_par_page=999999&apiKey=",apiKey_ij)
certif_api_json <- jsonlite::fromJSON(url)
data_meta_certificationsStats_init <- certif_api_json$certifications %>%
  as_tibble()

data_meta_certificationsStats_init_annee_terminales <- data_meta_certificationsStats_init %>%
  unnest(certificationsTerminales,names_sep = "certificationsTerminales") %>% 
  select(code_certification,certificationsTerminalescertificationsTerminalescode_certification,millesime) %>% 
  left_join(data_meta_certificationsStats_init,
            by=c("certificationsTerminalescertificationsTerminalescode_certification"="code_certification","millesime"))  %>% 
  select(-certificationsTerminalescertificationsTerminalescode_certification)


data_meta_certificationsStats_init <- data_meta_certificationsStats_init %>% 
  anti_join(data_meta_certificationsStats_init_annee_terminales,
            by=c("code_certification","millesime")) %>% 
  bind_rows(
    data_meta_certificationsStats_init_annee_terminales    
  )


data_meta_certificationsStats_init <- data_meta_certificationsStats_init%>% 
  select(code_certification,filiere,contains("salaire_12_mois")) %>%
  mutate(
    code_certification=case_when(
      filiere=="apprentissage"~paste0("CFD:",code_certification),
      filiere=="pro"~paste0("MEFSTAT11:",code_certification),
      filiere=="superieur"~paste0("SISE:",code_certification)
    ),
    couverture_salaire=  map_chr(data_meta_certificationsStats_init$`_meta`$messages,~ifelse(is.null(.),NA,.)),
    couverture_salaire=case_when(
      couverture_salaire=="Les taux ne peuvent pas être affichés car il n'y a pas assez d'élèves pour fournir une information fiable." ~"Non couvert - Sous le seuil de 20 élèves",
      is.na(salaire_12_mois_q1)~"Non couvert - Sans raison évidente",
      !is.na(salaire_12_mois_q1)~"Couvert",
      T ~couverture_salaire)
  ) 

## Appariement avec les données Rémunération ----

parcoursup_prepa_remuneration <- parcoursup_param %>% 
  pivot_longer(cols = intersect(names(.),c("ancien","self","nouveau")),names_to = "anciennete_certification_ci" ,values_to ="code_certification_possible") %>% 
  unnest("code_certification_possible") %>% 
  pivot_longer(cols = intersect(names(.),c("normal","inverse")),names_to = "appariement" ,values_to ="code_certification_possible") %>% 
  filter(!is.na(code_certification_possible)) %>% 
  distinct(CODEFORMATIONACCUEIL,code_certification_possible,appariement,type_certification,validite_code_certification,anciennete_certification_ci) %>% 
  mutate(
    appariement=factor(appariement,levels=c("normal","inverse")),
    anciennete_certification_ci=factor(anciennete_certification_ci,levels=c("self","nouveau","ancien"))
  ) 


parcoursup_prepa_remuneration_couvert <- parcoursup_prepa_remuneration %>% 
  inner_join(
    data_meta_certificationsStats_init ,
    by=c("code_certification_possible"="code_certification")
  ) %>%  
  distinct() %>% 
  group_by(CODEFORMATIONACCUEIL) %>%
  filter(as.numeric(appariement)==min(as.numeric(appariement))) %>%   
  ungroup() %>%
  distinct() %>% 
  group_by(CODEFORMATIONACCUEIL) %>%
  filter(as.numeric(type_certification)==min(as.numeric(type_certification))) %>% 
  ungroup() %>%
  distinct() %>% 
  group_by(CODEFORMATIONACCUEIL) %>%
  filter(as.numeric(anciennete_certification_ci)==min(as.numeric(anciennete_certification_ci))) %>% 
  ungroup() %>%
  distinct() %>% 
  group_by(CODEFORMATIONACCUEIL) %>%
  mutate(
    Couverture=case_when(
      n() > 1 ~"Non couvert - Plusieurs codes certification associés",
      T~couverture_salaire
    )
  ) %>% 
  ungroup() %>% 
  select(-validite_code_certification,-anciennete_certification_ci)


parcoursup_prepa_remuneration_non_couvert <- parcoursup_catalogue_init %>% 
  anti_join(
    parcoursup_prepa_remuneration_couvert %>% 
      ungroup() %>%
      distinct(CODEFORMATIONACCUEIL,Couverture),
    by="CODEFORMATIONACCUEIL"
  ) %>% 
  left_join(
    parcoursup_param_code_certification_init %>% 
      mutate(validite_code_certification=factor(validite_code_certification,levels=c("Valide","Non valide - Plusieurs codes certification associés","Non valide - Code inconnu"))) %>% 
      group_by(CODEFORMATIONACCUEIL) %>%
      filter(as.numeric(validite_code_certification)==min(as.numeric(validite_code_certification))) %>% 
      distinct(CODEFORMATIONACCUEIL,validite_code_certification) ,
    by="CODEFORMATIONACCUEIL"
  ) %>% 
  mutate(
    Couverture=case_when(
      !CODECFD %in% c(certifications_normalement_disponibles,NA) ~ "Non couvert - Nouvelle formation",
      validite_code_certification=="Valide" ~ "Non couvert - Sans raison évidente",
      validite_code_certification=="Non valide - Plusieurs codes certification associés" ~ "Non couvert - Plusieurs formations en annéee terminale associées",
      validite_code_certification=="Non valide - Code inconnu" ~ "Non couvert - code certification inconnu",
      !(is.na(CODEMEF)& is.na(CODECFD) & is.na(CODESISE) & is.na(LISTE_IDEO) & is.na(ID_RCO) & is.na(LISTE_RNCP)) ~ "Non couvert - code certification inconnu",
      T ~ "Non couvert - code certification absent"
    )
  ) %>% 
  select(-validite_code_certification)




parcoursup_remuneration  <- parcoursup_prepa_remuneration_couvert %>% 
  mutate_at(vars(salaire_12_mois_q1,salaire_12_mois_q2,salaire_12_mois_q3),~ifelse(Couverture!="Couvert",NA,.)) %>% 
  group_by(CODEFORMATIONACCUEIL) %>% 
  mutate(code_certification_possible=ifelse(Couverture=="Non couvert - Plusieurs codes certification associés",paste0(code_certification_possible,collapse = ";",sep=""),code_certification_possible)) %>% 
  ungroup() %>%
  distinct(CODEFORMATIONACCUEIL,Couverture,code_certification_possible,salaire_12_mois_q1,salaire_12_mois_q2,salaire_12_mois_q3)  %>% 
  bind_rows(
    parcoursup_prepa_remuneration_non_couvert %>% 
      distinct(CODEFORMATIONACCUEIL,Couverture)
  ) %>% 
  select(CODEFORMATIONACCUEIL,code_certification_possible,salaire_12_mois_q1,salaire_12_mois_q2,salaire_12_mois_q3,Couverture) %>% 
  rename(
    code_certification_salaire=code_certification_possible,
    couverture_salaire=Couverture
  )
