# Script d'import des données utiles tout au long de l'appariement.
# 
# Son exécution peut être chronophage, à la fin du script une sauvegarde de l'image des données 
# importées est réalisée dans le fichier prepa_ps_2025.RData qui pourra être appelé directement par la suite.



# Import des données ----

## Données BCN ----
# Import des différentes tables depuis le site BCN

# https://bcn.depp.education.fr/bcn/workspace/viewTable/n/N_MEF
n_mef <- read_csv2("https://bcn.depp.education.fr/bcn/index.php/export/CSV?n=N_MEF&separator=;")
# https://bcn.depp.education.fr/bcn/workspace/viewTable/n/N_FORMATION_DIPLOME
n_formation_diplome <- read_csv2("https://bcn.depp.education.fr/bcn/index.php/export/CSV?n=N_FORMATION_DIPLOME&separator=;")

# https://bcn.depp.education.fr/bcn/workspace/viewTable/n/N_NIVEAU_FORMATION_DIPLOME
n_niveau_formation_diplome <- read_csv2("https://bcn.depp.education.fr/bcn/index.php/export/CSV?n=N_NIVEAU_FORMATION_DIPLOME&separator=;")

# https://bcn.depp.education.fr/bcn/workspace/viewTable/n/N_DIPLOME_SISE
n_diplome_sise <- read_csv2("https://bcn.depp.education.fr/bcn/index.php/export/CSV?n=N_DIPLOME_SISE&separator=;")

# https://bcn.depp.education.fr/bcn/index.php/workspace/viewTable/n/V_FORMATION_DIPLOME/nbElements/20
v_formation_diplome <- read_csv2("https://bcn.depp.education.fr/bcn/index.php/export/CSV?n=V_FORMATION_DIPLOME&separator=;")

continuum <- 
  n_formation_diplome %>%
  select(FORMATION_DIPLOME,contains("ANCIEN_DIPLOME_")) %>%
  mutate_all(as.character) %>%
  pivot_longer(cols=-FORMATION_DIPLOME) %>%
  drop_na()%>%
  select(FORMATION_DIPLOME,value) %>%
  setNames(c("nouveau_cfd","ancien_cfd")) %>% 
  filter(!ancien_cfd %in% n_formation_diplome$FORMATION_DIPLOME) %>% 
  bind_rows(
    n_formation_diplome %>%
      select(FORMATION_DIPLOME,contains("NOUVEAU_DIPLOME_"),contains("ANCIEN_DIPLOME_")) %>%
      mutate_all(as.character) %>%
      pivot_longer(cols=-FORMATION_DIPLOME) %>% 
      filter(is.na(value)) %>% 
      group_by(FORMATION_DIPLOME) %>% 
      filter(n()==14) %>% 
      ungroup() %>%
      distinct(FORMATION_DIPLOME) %>% 
      setNames("nouveau_cfd") %>%  
      mutate(ancien_cfd=nouveau_cfd)
  ) %>%
  bind_rows(
    n_formation_diplome %>%
      select(FORMATION_DIPLOME,contains("NOUVEAU_DIPLOME_")) %>%
      mutate_all(as.character) %>%
      pivot_longer(cols=-FORMATION_DIPLOME) %>%
      drop_na() %>%
      select(FORMATION_DIPLOME,value) %>%
      setNames(c("ancien_cfd","nouveau_cfd"))
  ) %>%
  distinct() %>%
  mutate(last_new=NA)


## Données onisep ----
### Onisep - Idéo-Formations initiales en France ----
# Récupération des formations initiales Onisep via API
#https://opendata.onisep.fr/data/5fa591127f501/2-ideo-formations-initiales-en-france.htm?tab=table_65f84591dcff4&id=65f84591dcff4&pluginCode=table&idtf=2&cms_mode=ON_&lheo=0&pid=f0389fae3310c17132b888ea3286c8c397c656a9&from=30

table_onisep <-  jsonlite::fromJSON("https://api.opendata.onisep.fr/downloads/5fa591127f501/5fa591127f501.json") %>% 
  as_tibble() %>% 
  mutate_all(~ifelse(.=="",NA,.))

# Extraction et nettoyage des données nécessaires
ideo_formations_initiales_en_france_simpli <- table_onisep %>% 
  select(code_rncp,url_et_id_onisep)  %>% 
  drop_na() %>% 
  mutate(
    ideo=str_remove(url_et_id_onisep,"https://www.onisep.fr/http/redirection/formation/slug/")
  ) %>% 
  select(code_rncp,ideo) %>% 
  rename(`code RNCP`=code_rncp)


### Onisep - Table de passage codes certifications et formations----
# Récupération des correspondances entre codes certifications et formations

table_de_passage_codes_certifications_et_formations <- jsonlite::fromJSON("https://api.opendata.onisep.fr/downloads/6152ccdf850ef/6152ccdf850ef.json") %>% 
  as_tibble() %>% 
  mutate_all(~ifelse(.=="",NA,.))




## CertifInfos ----
# Import des données depuis data.gouv.fr
# https://www.data.gouv.fr/fr/datasets/referentiel-national-des-certifications/


opendata_certifinfo <- read_csv("https://tabular-api.data.gouv.fr/api/resources/f2981d6f-e55c-42cd-8eba-3e891777e222/data/csv/")

# ensemble_codes_ci <- opendata_certifinfo %>% 
#   select(Code_Diplome,Code_Ancien_Diplome) %>% 
#   pivot_longer(cols = everything()) %>% 
#   drop_na() %>% 
#   select(value) %>% 
#   setNames("code_ci") %>% 
#   distinct(code_ci) %>% 
#   mutate_all(as.character)
# 
# continuum_ci  <- ensemble_codes_ci %>% 
#   mutate(data=map(code_ci,function(ci_cible){
#     ci_cible_temp <- as.character(ci_cible)   
#     rang <- 0
#     while (opendata_certifinfo %>% 
#            select(Code_Diplome,Code_Ancien_Diplome) %>% 
#            filter(Code_Ancien_Diplome==ci_cible_temp) %>% 
#            pull(Code_Diplome ) %>% 
#            length() == 1) {
#       
#       ci_cible_temp <-  opendata_certifinfo %>% 
#         select(Code_Diplome,Code_Ancien_Diplome) %>%
#         mutate_all(as.character) %>% 
#         filter(Code_Ancien_Diplome==ci_cible_temp) %>% 
#         pull(Code_Diplome )
#       
#       rang <- rang+1
#       
#     }
#     
#     temp <- tibble(
#       last_new_ci=ci_cible_temp,
#       rang=rang
#     )
#     return(temp)
#     
#   })) %>% 
#   unnest(data)


## ACCE ----
# Import des données ACCE
# https://www.education.gouv.fr/acce/search.php?mode=simple
ACCE_UAI <- data.table::fread(file.path(chemin_racine_data,"ACCE/Extraction ACCE.csv"),
                              encoding = "Latin-1") %>% 
  mutate(academie=str_pad(academie,side = "left",pad="0",width=2))

ACCE_UAI_MERE <- read_csv2(file.path(chemin_racine_data,"ACCE/ACCE_UAI_MERE.csv"), 
                           locale = locale(encoding = "ISO-8859-1"))



## Import Parcoursup----
# Import des données Parcoursup et correspondances

parcoursup_catalogue_init <- read_excel(file.path(chemin_racine_data,"parcoursup/2025/liste_Formation_inserJeunes_06_01_2025/liste_Formation_inserJeunes_06_01_2025.xls"))
correspondance_formation_scope_exposition <- read_excel(file.path(chemin_racine_data,"correspondance_formation_scope_exposition.xlsx"))

## Association PS <-> SISE réalisées pour l'appariement en 2024 et 2025 pour :
#       - les Licences Pro, 
#       - les écoles de commerce, 
#       - les formations des écoles d'ingénieurs


association_ps_sise <- read_excel(file.path(chemin_racine_data,"association_ps_sise.xlsx"),
                                   sheet = "ps<->sise")

parcoursup_catalogue_init <- parcoursup_catalogue_init %>% 
  anti_join(
    association_ps_sise %>% 
      select(CODEFORMATIONACCUEIL,code_certification_retenu) %>% 
      drop_na() %>% 
      mutate(code_certification_retenu=str_remove(code_certification_retenu,"SISE:")),
    by="CODEFORMATIONACCUEIL"
  ) %>% 
  bind_rows(
    parcoursup_catalogue_init %>%
      select(-CODESISE) %>% 
      inner_join(
        association_ps_sise %>% 
          select(CODEFORMATIONACCUEIL,code_certification_retenu) %>% 
          drop_na() %>% 
          mutate(code_certification_retenu=str_remove(code_certification_retenu,"SISE:")) %>% 
          rename(CODESISE=code_certification_retenu),
        by="CODEFORMATIONACCUEIL"
      )    
  )




