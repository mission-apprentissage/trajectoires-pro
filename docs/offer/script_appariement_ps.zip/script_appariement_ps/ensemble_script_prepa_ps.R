# Chargement des librairies ----
library(tidyverse)
library(readxl)

# lancer les scripts d'appariement ----
##1- Imports des données ----
#Ce premier script d'import des données est potentiellement chronophage,
#en fin de script il enregistre une image des données prepa_ps_2025.RData qu'on peut charger plutôt que de relancer systématiquement le premier script.


#modifier ici le chemin vers le catalogue initial de Parcoursup
chemin_parcoursup_catalogue_init <- "../data_utiles/parcoursup/2025/liste_Formation_inserJeunes_06_01_2025/liste_Formation_inserJeunes_06_01_2025.xls" 

# Définition du chemin racine pour les données (à adapter selon l'emplacement des fichiers)
chemin_racine_data <- "data_utiles"
choix_api_exposition <- "recette"

### Clés API utiles au moment de l'import des données ----

#### API Exposition InserJeunes ----
# apiKey_ij <- XXXXXXX #clé de l'API Exposition InserJeunes: https://exposition.inserjeunes.beta.gouv.fr/api/doc/

#### API Certif Info ----
# token_ci <- XXXXXXX #clé de l’API Certif Info : https://api-certifinfo.intercariforef.org/docs

urls <- list(
  exposition_ij= list(
    production = "https://exposition.inserjeunes.beta.gouv.fr",
    recette = "https://recette.exposition.inserjeunes.incubateur.net"
  )
)
  

ensemble_key <- readRDS("../data/ensemble_key.rds") #les clés peuvent être stockées dans un fichier si nécéssaire
apiKey_ij <- ensemble_key$apiKey_ij
token_ci <- ensemble_key$token_ci

# source("scripts_appariements/0_script_prepa_ps_import_data.R")

##2- Recherche des codes certification potentiels ----
# source("scripts_appariements/1_script_prepa_ps_prepa_data.R")
# jsonlite::write_json(parcoursup_param,"output/parcoursup_param.json")


# Sauvegarde de l'image des données importées et pré-traitées
# ___________________________________________________________
# !!! Il est fortement conseillé d'enregistrer les données importées et pré-traitées car ces étapes
# sont chronophages.
# ___________________________________________________________
# save.image("prepa_ps_2025.RData")
# rm(list=ls())
# Charger l'image des données predemment importées
load("prepa_ps_2025.RData")

##3- Appariements avec les données Exposition Inserjeunes et autres services ----
source("scripts_appariements/2_1_script_prepa_ps_focus_insertion.R")
source("scripts_appariements/2_2_script_prepa_ps_focus_remuneration.R")
source("scripts_appariements/2_3_script_prepa_ps_focus_passage_reussite.R")

##4- Agrégation des appariements ----
source("scripts_appariements/3_script_prepa_ps_agregation_focus.R")
# write_csv2(parcoursup_catalogue_final,"output/parcoursup_catalogue_final.csv")

## Analyse de couverture ----
source("scripts_appariements/4_script_prepa_ps_analyse_couverture.R")

stats_parcoursup_catalogue_Couverture_insertion_avant_MIJ_synthese

stats_catalogue_parcoursup_couverture

stats_catalogue_parcoursup_couverture_synthese
